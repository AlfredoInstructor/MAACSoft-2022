﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formbusquedahab
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Buttonreservas = New System.Windows.Forms.Button()
        Me.Buttonldisponible = New System.Windows.Forms.Button()
        Me.ButtonLtotal = New System.Windows.Forms.Button()
        Me.Buttonocupadas = New System.Windows.Forms.Button()
        Me.Buttoncdisponible = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridViewhabitaciones = New System.Windows.Forms.DataGridView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.RB2 = New System.Windows.Forms.RadioButton()
        Me.RB1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ButtonBR = New System.Windows.Forms.Button()
        Me.CheckBox2C = New System.Windows.Forms.CheckBox()
        Me.CheckBox1C = New System.Windows.Forms.CheckBox()
        Me.CheckBoxAC = New System.Windows.Forms.CheckBox()
        Me.CheckBoxTV = New System.Windows.Forms.CheckBox()
        Me.CheckBoxFRI = New System.Windows.Forms.CheckBox()
        Me.CheckBoxVF = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Buttonbuscar = New System.Windows.Forms.Button()
        Me.Buttoncancelar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridViewhabitaciones, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gray
        Me.GroupBox1.Controls.Add(Me.Buttonreservas)
        Me.GroupBox1.Controls.Add(Me.Buttonldisponible)
        Me.GroupBox1.Controls.Add(Me.ButtonLtotal)
        Me.GroupBox1.Controls.Add(Me.Buttonocupadas)
        Me.GroupBox1.Controls.Add(Me.Buttoncdisponible)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Controls.Add(Me.Buttoncancelar)
        Me.GroupBox1.Location = New System.Drawing.Point(1, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(729, 379)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Buttonreservas
        '
        Me.Buttonreservas.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttonreservas.Location = New System.Drawing.Point(614, 293)
        Me.Buttonreservas.Name = "Buttonreservas"
        Me.Buttonreservas.Size = New System.Drawing.Size(108, 39)
        Me.Buttonreservas.TabIndex = 16
        Me.Buttonreservas.Text = "RESERVADAS"
        Me.Buttonreservas.UseVisualStyleBackColor = False
        '
        'Buttonldisponible
        '
        Me.Buttonldisponible.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttonldisponible.Location = New System.Drawing.Point(614, 248)
        Me.Buttonldisponible.Name = "Buttonldisponible"
        Me.Buttonldisponible.Size = New System.Drawing.Size(108, 39)
        Me.Buttonldisponible.TabIndex = 15
        Me.Buttonldisponible.Text = "LISTADO DISPONIBLE"
        Me.Buttonldisponible.UseVisualStyleBackColor = False
        '
        'ButtonLtotal
        '
        Me.ButtonLtotal.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonLtotal.Location = New System.Drawing.Point(614, 203)
        Me.ButtonLtotal.Name = "ButtonLtotal"
        Me.ButtonLtotal.Size = New System.Drawing.Size(108, 39)
        Me.ButtonLtotal.TabIndex = 14
        Me.ButtonLtotal.Text = "LISTADO TOTAL"
        Me.ButtonLtotal.UseVisualStyleBackColor = False
        '
        'Buttonocupadas
        '
        Me.Buttonocupadas.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttonocupadas.Location = New System.Drawing.Point(615, 158)
        Me.Buttonocupadas.Name = "Buttonocupadas"
        Me.Buttonocupadas.Size = New System.Drawing.Size(108, 39)
        Me.Buttonocupadas.TabIndex = 13
        Me.Buttonocupadas.Text = "CANTIDAD OCUPADAS"
        Me.Buttonocupadas.UseVisualStyleBackColor = False
        '
        'Buttoncdisponible
        '
        Me.Buttoncdisponible.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttoncdisponible.Location = New System.Drawing.Point(615, 113)
        Me.Buttoncdisponible.Name = "Buttoncdisponible"
        Me.Buttoncdisponible.Size = New System.Drawing.Size(108, 39)
        Me.Buttoncdisponible.TabIndex = 12
        Me.Buttoncdisponible.Text = "CANTIDAD DISPONIBLES"
        Me.Buttoncdisponible.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Silver
        Me.GroupBox2.Controls.Add(Me.DataGridViewhabitaciones)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 113)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(591, 247)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Lista de Habitaciones:"
        '
        'DataGridViewhabitaciones
        '
        Me.DataGridViewhabitaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewhabitaciones.Location = New System.Drawing.Point(9, 20)
        Me.DataGridViewhabitaciones.Name = "DataGridViewhabitaciones"
        Me.DataGridViewhabitaciones.Size = New System.Drawing.Size(576, 221)
        Me.DataGridViewhabitaciones.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Silver
        Me.GroupBox3.Controls.Add(Me.RB2)
        Me.GroupBox3.Controls.Add(Me.RB1)
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.TextBox1)
        Me.GroupBox3.Controls.Add(Me.Buttonbuscar)
        Me.GroupBox3.Location = New System.Drawing.Point(15, 19)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(705, 88)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Buscar:"
        '
        'RB2
        '
        Me.RB2.AutoSize = True
        Me.RB2.Location = New System.Drawing.Point(9, 43)
        Me.RB2.Name = "RB2"
        Me.RB2.Size = New System.Drawing.Size(100, 17)
        Me.RB2.TabIndex = 16
        Me.RB2.Text = "Nro Documento"
        Me.RB2.UseVisualStyleBackColor = True
        '
        'RB1
        '
        Me.RB1.AutoSize = True
        Me.RB1.Checked = True
        Me.RB1.Location = New System.Drawing.Point(9, 19)
        Me.RB1.Name = "RB1"
        Me.RB1.Size = New System.Drawing.Size(96, 17)
        Me.RB1.TabIndex = 15
        Me.RB1.TabStop = True
        Me.RB1.Text = "Nro Habitacion"
        Me.RB1.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.LightGray
        Me.GroupBox4.Controls.Add(Me.ButtonBR)
        Me.GroupBox4.Controls.Add(Me.CheckBox2C)
        Me.GroupBox4.Controls.Add(Me.CheckBox1C)
        Me.GroupBox4.Controls.Add(Me.CheckBoxAC)
        Me.GroupBox4.Controls.Add(Me.CheckBoxTV)
        Me.GroupBox4.Controls.Add(Me.CheckBoxFRI)
        Me.GroupBox4.Controls.Add(Me.CheckBoxVF)
        Me.GroupBox4.Location = New System.Drawing.Point(305, 10)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(394, 72)
        Me.GroupBox4.TabIndex = 14
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Disponibles"
        '
        'ButtonBR
        '
        Me.ButtonBR.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ButtonBR.Location = New System.Drawing.Point(285, 18)
        Me.ButtonBR.Name = "ButtonBR"
        Me.ButtonBR.Size = New System.Drawing.Size(103, 39)
        Me.ButtonBR.TabIndex = 17
        Me.ButtonBR.Text = "BUSCAR POR REFERENCIAS"
        Me.ButtonBR.UseVisualStyleBackColor = False
        '
        'CheckBox2C
        '
        Me.CheckBox2C.AutoSize = True
        Me.CheckBox2C.Location = New System.Drawing.Point(22, 46)
        Me.CheckBox2C.Name = "CheckBox2C"
        Me.CheckBox2C.Size = New System.Drawing.Size(65, 17)
        Me.CheckBox2C.TabIndex = 27
        Me.CheckBox2C.Text = "2 CAMA"
        Me.CheckBox2C.UseVisualStyleBackColor = True
        '
        'CheckBox1C
        '
        Me.CheckBox1C.AutoSize = True
        Me.CheckBox1C.Checked = True
        Me.CheckBox1C.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1C.Location = New System.Drawing.Point(22, 18)
        Me.CheckBox1C.Name = "CheckBox1C"
        Me.CheckBox1C.Size = New System.Drawing.Size(65, 17)
        Me.CheckBox1C.TabIndex = 26
        Me.CheckBox1C.Text = "1 CAMA"
        Me.CheckBox1C.UseVisualStyleBackColor = True
        '
        'CheckBoxAC
        '
        Me.CheckBoxAC.AutoSize = True
        Me.CheckBoxAC.Location = New System.Drawing.Point(239, 48)
        Me.CheckBoxAC.Name = "CheckBoxAC"
        Me.CheckBoxAC.Size = New System.Drawing.Size(40, 17)
        Me.CheckBoxAC.TabIndex = 17
        Me.CheckBoxAC.Text = "AC"
        Me.CheckBoxAC.UseVisualStyleBackColor = True
        '
        'CheckBoxTV
        '
        Me.CheckBoxTV.AutoSize = True
        Me.CheckBoxTV.Location = New System.Drawing.Point(239, 19)
        Me.CheckBoxTV.Name = "CheckBoxTV"
        Me.CheckBoxTV.Size = New System.Drawing.Size(40, 17)
        Me.CheckBoxTV.TabIndex = 25
        Me.CheckBoxTV.Text = "TV"
        Me.CheckBoxTV.UseVisualStyleBackColor = True
        '
        'CheckBoxFRI
        '
        Me.CheckBoxFRI.AutoSize = True
        Me.CheckBoxFRI.Location = New System.Drawing.Point(109, 47)
        Me.CheckBoxFRI.Name = "CheckBoxFRI"
        Me.CheckBoxFRI.Size = New System.Drawing.Size(81, 17)
        Me.CheckBoxFRI.TabIndex = 21
        Me.CheckBoxFRI.Text = "FRIGOBAR"
        Me.CheckBoxFRI.UseVisualStyleBackColor = True
        '
        'CheckBoxVF
        '
        Me.CheckBoxVF.AutoSize = True
        Me.CheckBoxVF.Location = New System.Drawing.Point(109, 19)
        Me.CheckBoxVF.Name = "CheckBoxVF"
        Me.CheckBoxVF.Size = New System.Drawing.Size(123, 17)
        Me.CheckBoxVF.TabIndex = 20
        Me.CheckBoxVF.Text = "VENTANA FRENTE"
        Me.CheckBoxVF.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(115, 28)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(92, 20)
        Me.TextBox1.TabIndex = 13
        '
        'Buttonbuscar
        '
        Me.Buttonbuscar.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttonbuscar.Location = New System.Drawing.Point(213, 18)
        Me.Buttonbuscar.Name = "Buttonbuscar"
        Me.Buttonbuscar.Size = New System.Drawing.Size(86, 39)
        Me.Buttonbuscar.TabIndex = 9
        Me.Buttonbuscar.Text = "BUSCAR"
        Me.Buttonbuscar.UseVisualStyleBackColor = False
        '
        'Buttoncancelar
        '
        Me.Buttoncancelar.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttoncancelar.Location = New System.Drawing.Point(615, 338)
        Me.Buttoncancelar.Name = "Buttoncancelar"
        Me.Buttoncancelar.Size = New System.Drawing.Size(108, 35)
        Me.Buttoncancelar.TabIndex = 10
        Me.Buttoncancelar.Text = "Cancelar"
        Me.Buttoncancelar.UseVisualStyleBackColor = False
        '
        'Formbusquedahab
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(734, 381)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Formbusquedahab"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Búsqueda de Habitaciones:"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridViewhabitaciones, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Buttoncancelar As System.Windows.Forms.Button
    Friend WithEvents Buttonbuscar As System.Windows.Forms.Button
    Friend WithEvents DataGridViewhabitaciones As System.Windows.Forms.DataGridView
    Friend WithEvents Buttoncdisponible As System.Windows.Forms.Button
    Friend WithEvents Buttonocupadas As System.Windows.Forms.Button
    Friend WithEvents ButtonLtotal As System.Windows.Forms.Button
    Friend WithEvents Buttonldisponible As System.Windows.Forms.Button
    Friend WithEvents Buttonreservas As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBoxTV As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxFRI As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxVF As System.Windows.Forms.CheckBox
    Friend WithEvents RB2 As System.Windows.Forms.RadioButton
    Friend WithEvents RB1 As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBoxAC As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2C As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1C As System.Windows.Forms.CheckBox
    Friend WithEvents ButtonBR As System.Windows.Forms.Button
End Class
