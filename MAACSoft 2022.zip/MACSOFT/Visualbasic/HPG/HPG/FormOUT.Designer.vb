﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormOUT
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxbuscar = New System.Windows.Forms.TextBox()
        Me.Buttoncancelar = New System.Windows.Forms.Button()
        Me.DataGridViewout = New System.Windows.Forms.DataGridView()
        Me.Buttontotal = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBoxpagar = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBoxid = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBoxFentrada = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBoxvalor = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxNhab = New System.Windows.Forms.TextBox()
        Me.TextBoxND = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ButtonOUT = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridViewout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gray
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.TextBoxbuscar)
        Me.GroupBox1.Controls.Add(Me.Buttoncancelar)
        Me.GroupBox1.Controls.Add(Me.DataGridViewout)
        Me.GroupBox1.Controls.Add(Me.Buttontotal)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.ButtonOUT)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(482, 371)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'TextBoxbuscar
        '
        Me.TextBoxbuscar.Location = New System.Drawing.Point(127, 24)
        Me.TextBoxbuscar.Name = "TextBoxbuscar"
        Me.TextBoxbuscar.Size = New System.Drawing.Size(137, 20)
        Me.TextBoxbuscar.TabIndex = 12
        '
        'Buttoncancelar
        '
        Me.Buttoncancelar.Location = New System.Drawing.Point(400, 336)
        Me.Buttoncancelar.Name = "Buttoncancelar"
        Me.Buttoncancelar.Size = New System.Drawing.Size(75, 23)
        Me.Buttoncancelar.TabIndex = 0
        Me.Buttoncancelar.Text = "CANCELAR"
        Me.Buttoncancelar.UseVisualStyleBackColor = True
        '
        'DataGridViewout
        '
        Me.DataGridViewout.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewout.Location = New System.Drawing.Point(6, 63)
        Me.DataGridViewout.Name = "DataGridViewout"
        Me.DataGridViewout.Size = New System.Drawing.Size(463, 100)
        Me.DataGridViewout.TabIndex = 5
        '
        'Buttontotal
        '
        Me.Buttontotal.Location = New System.Drawing.Point(401, 278)
        Me.Buttontotal.Name = "Buttontotal"
        Me.Buttontotal.Size = New System.Drawing.Size(75, 23)
        Me.Buttontotal.TabIndex = 4
        Me.Buttontotal.Text = "TOTAL"
        Me.Buttontotal.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Gray
        Me.Label6.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(27, 245)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 18)
        Me.Label6.TabIndex = 3
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.DarkGray
        Me.GroupBox2.Controls.Add(Me.TextBoxpagar)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.TextBoxid)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.TextBoxFentrada)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.TextBoxvalor)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.TextBoxNhab)
        Me.GroupBox2.Controls.Add(Me.TextBoxND)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 169)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(382, 190)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'TextBoxpagar
        '
        Me.TextBoxpagar.Location = New System.Drawing.Point(128, 164)
        Me.TextBoxpagar.Name = "TextBoxpagar"
        Me.TextBoxpagar.Size = New System.Drawing.Size(130, 20)
        Me.TextBoxpagar.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 164)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(109, 18)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Total a Pagar:"
        '
        'TextBoxid
        '
        Me.TextBoxid.Location = New System.Drawing.Point(297, 16)
        Me.TextBoxid.Name = "TextBoxid"
        Me.TextBoxid.Size = New System.Drawing.Size(83, 20)
        Me.TextBoxid.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(262, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 18)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "ID "
        '
        'TextBoxFentrada
        '
        Me.TextBoxFentrada.Location = New System.Drawing.Point(128, 89)
        Me.TextBoxFentrada.Name = "TextBoxFentrada"
        Me.TextBoxFentrada.Size = New System.Drawing.Size(130, 20)
        Me.TextBoxFentrada.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 89)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(114, 18)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Fecha entrada:"
        '
        'TextBoxvalor
        '
        Me.TextBoxvalor.Location = New System.Drawing.Point(128, 130)
        Me.TextBoxvalor.Name = "TextBoxvalor"
        Me.TextBoxvalor.Size = New System.Drawing.Size(130, 20)
        Me.TextBoxvalor.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(0, 130)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 18)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Valor Habitacion:"
        '
        'TextBoxNhab
        '
        Me.TextBoxNhab.Location = New System.Drawing.Point(128, 52)
        Me.TextBoxNhab.Name = "TextBoxNhab"
        Me.TextBoxNhab.Size = New System.Drawing.Size(130, 20)
        Me.TextBoxNhab.TabIndex = 4
        '
        'TextBoxND
        '
        Me.TextBoxND.Location = New System.Drawing.Point(129, 18)
        Me.TextBoxND.Name = "TextBoxND"
        Me.TextBoxND.Size = New System.Drawing.Size(130, 20)
        Me.TextBoxND.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nro Habitacion:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nro Documento"
        '
        'ButtonOUT
        '
        Me.ButtonOUT.Location = New System.Drawing.Point(400, 307)
        Me.ButtonOUT.Name = "ButtonOUT"
        Me.ButtonOUT.Size = New System.Drawing.Size(75, 23)
        Me.ButtonOUT.TabIndex = 1
        Me.ButtonOUT.Text = "ACEPTAR"
        Me.ButtonOUT.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(4, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 18)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Nro Documento"
        '
        'FormOUT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(505, 398)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FormOUT"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CHECK-OUT"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridViewout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxNhab As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxND As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ButtonOUT As System.Windows.Forms.Button
    Friend WithEvents Buttoncancelar As System.Windows.Forms.Button
    Friend WithEvents TextBoxvalor As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Buttontotal As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBoxFentrada As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBoxbuscar As System.Windows.Forms.TextBox
    Friend WithEvents DataGridViewout As System.Windows.Forms.DataGridView
    Friend WithEvents TextBoxid As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBoxpagar As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
