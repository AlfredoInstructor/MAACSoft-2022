﻿Public Class Formloguin

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If TextBox1.Text = "maac" And TextBox2.Text = "4321" Then
                FormMenuinicio.Show()
                Me.Hide()
            Else
                If TextBox1.Text = "" And TextBox2.Text = "" Then
                    MsgBox("No se ha encontrado ningún nombre de usuario / contraseña", MsgBoxStyle.Critical, "Error")
                Else
                    If TextBox1.Text = "" Then
                        MsgBox("No se encontró ningún nombre de usuario", MsgBoxStyle.Critical, "Error")
                    Else
                        If TextBox2.Text = "" Then
                            MsgBox("No se encontró una contraseña", MsgBoxStyle.Critical, "Error")
                        Else
                            MsgBox("nombre de usuario y / o contraseña inválido", MsgBoxStyle.Critical, "Error")
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If Asc(e.KeyChar) = 13 Then
            Button1.Focus()

        End If
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class
