﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formbusquedahuesped
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxconsulta = New System.Windows.Forms.TextBox()
        Me.Buttoncancelar = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridViewLista = New System.Windows.Forms.DataGridView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBoxsexo = New System.Windows.Forms.TextBox()
        Me.TextBoxND = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBoxciudad = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxtel = New System.Windows.Forms.TextBox()
        Me.TextBoxdireccion = New System.Windows.Forms.TextBox()
        Me.TextBoxTD = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBoxnombre = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBoxemail = New System.Windows.Forms.TextBox()
        Me.TextBoxapellido = New System.Windows.Forms.TextBox()
        Me.Buttonmodificar = New System.Windows.Forms.Button()
        Me.Buttoneliminar = New System.Windows.Forms.Button()
        Me.Buttontodos = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridViewLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Silver
        Me.GroupBox1.Controls.Add(Me.TextBoxconsulta)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(228, 63)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Buscar por nombre o tipo de documento:"
        '
        'TextBoxconsulta
        '
        Me.TextBoxconsulta.Location = New System.Drawing.Point(10, 19)
        Me.TextBoxconsulta.Name = "TextBoxconsulta"
        Me.TextBoxconsulta.Size = New System.Drawing.Size(212, 20)
        Me.TextBoxconsulta.TabIndex = 1
        '
        'Buttoncancelar
        '
        Me.Buttoncancelar.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttoncancelar.Location = New System.Drawing.Point(416, 503)
        Me.Buttoncancelar.Name = "Buttoncancelar"
        Me.Buttoncancelar.Size = New System.Drawing.Size(75, 26)
        Me.Buttoncancelar.TabIndex = 2
        Me.Buttoncancelar.Text = "Cancelar"
        Me.Buttoncancelar.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Silver
        Me.GroupBox2.Controls.Add(Me.DataGridViewLista)
        Me.GroupBox2.Location = New System.Drawing.Point(13, 73)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(478, 160)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Lista de Huespedes"
        '
        'DataGridViewLista
        '
        Me.DataGridViewLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewLista.Location = New System.Drawing.Point(7, 20)
        Me.DataGridViewLista.Name = "DataGridViewLista"
        Me.DataGridViewLista.Size = New System.Drawing.Size(465, 134)
        Me.DataGridViewLista.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Silver
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.TextBoxsexo)
        Me.GroupBox3.Controls.Add(Me.TextBoxND)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.TextBoxciudad)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.TextBoxtel)
        Me.GroupBox3.Controls.Add(Me.TextBoxdireccion)
        Me.GroupBox3.Controls.Add(Me.TextBoxTD)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.TextBoxnombre)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.TextBoxemail)
        Me.GroupBox3.Controls.Add(Me.TextBoxapellido)
        Me.GroupBox3.Location = New System.Drawing.Point(13, 239)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(397, 290)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Huesped"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Silver
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(8, 264)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 17)
        Me.Label10.TabIndex = 59
        Me.Label10.Text = "Sexo:"
        '
        'TextBoxsexo
        '
        Me.TextBoxsexo.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxsexo.Location = New System.Drawing.Point(150, 259)
        Me.TextBoxsexo.Name = "TextBoxsexo"
        Me.TextBoxsexo.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxsexo.TabIndex = 58
        '
        'TextBoxND
        '
        Me.TextBoxND.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxND.Location = New System.Drawing.Point(150, 83)
        Me.TextBoxND.Name = "TextBoxND"
        Me.TextBoxND.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxND.TabIndex = 57
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Silver
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(8, 146)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(135, 17)
        Me.Label9.TabIndex = 56
        Me.Label9.Text = "Ciudad Origen:"
        '
        'TextBoxciudad
        '
        Me.TextBoxciudad.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxciudad.Location = New System.Drawing.Point(150, 141)
        Me.TextBoxciudad.Name = "TextBoxciudad"
        Me.TextBoxciudad.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxciudad.TabIndex = 55
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Silver
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 235)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 17)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Email:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Silver
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 207)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Teléfono:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Silver
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(5, 178)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 17)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Dirección:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(5, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 17)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Apellido:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Silver
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 17)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Nombre:"
        '
        'TextBoxtel
        '
        Me.TextBoxtel.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxtel.Location = New System.Drawing.Point(150, 202)
        Me.TextBoxtel.Name = "TextBoxtel"
        Me.TextBoxtel.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxtel.TabIndex = 38
        '
        'TextBoxdireccion
        '
        Me.TextBoxdireccion.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxdireccion.Location = New System.Drawing.Point(150, 173)
        Me.TextBoxdireccion.Name = "TextBoxdireccion"
        Me.TextBoxdireccion.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxdireccion.TabIndex = 37
        '
        'TextBoxTD
        '
        Me.TextBoxTD.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTD.Location = New System.Drawing.Point(150, 113)
        Me.TextBoxTD.Name = "TextBoxTD"
        Me.TextBoxTD.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxTD.TabIndex = 36
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Silver
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(5, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 17)
        Me.Label3.TabIndex = 43
        Me.Label3.Text = "Tipo Doc:"
        '
        'TextBoxnombre
        '
        Me.TextBoxnombre.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxnombre.Location = New System.Drawing.Point(150, 24)
        Me.TextBoxnombre.Name = "TextBoxnombre"
        Me.TextBoxnombre.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxnombre.TabIndex = 40
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Silver
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(5, 90)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(81, 17)
        Me.Label7.TabIndex = 47
        Me.Label7.Text = "Nro Doc:"
        '
        'TextBoxemail
        '
        Me.TextBoxemail.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxemail.Location = New System.Drawing.Point(150, 230)
        Me.TextBoxemail.Name = "TextBoxemail"
        Me.TextBoxemail.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxemail.TabIndex = 39
        '
        'TextBoxapellido
        '
        Me.TextBoxapellido.Font = New System.Drawing.Font("Lucida Console", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxapellido.Location = New System.Drawing.Point(150, 52)
        Me.TextBoxapellido.Name = "TextBoxapellido"
        Me.TextBoxapellido.Size = New System.Drawing.Size(187, 22)
        Me.TextBoxapellido.TabIndex = 35
        '
        'Buttonmodificar
        '
        Me.Buttonmodificar.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttonmodificar.Location = New System.Drawing.Point(416, 461)
        Me.Buttonmodificar.Name = "Buttonmodificar"
        Me.Buttonmodificar.Size = New System.Drawing.Size(75, 26)
        Me.Buttonmodificar.TabIndex = 5
        Me.Buttonmodificar.Text = "Modificar"
        Me.Buttonmodificar.UseVisualStyleBackColor = False
        '
        'Buttoneliminar
        '
        Me.Buttoneliminar.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttoneliminar.Location = New System.Drawing.Point(416, 420)
        Me.Buttoneliminar.Name = "Buttoneliminar"
        Me.Buttoneliminar.Size = New System.Drawing.Size(75, 26)
        Me.Buttoneliminar.TabIndex = 6
        Me.Buttoneliminar.Text = "Eliminar"
        Me.Buttoneliminar.UseVisualStyleBackColor = False
        '
        'Buttontodos
        '
        Me.Buttontodos.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttontodos.Location = New System.Drawing.Point(308, 38)
        Me.Buttontodos.Name = "Buttontodos"
        Me.Buttontodos.Size = New System.Drawing.Size(177, 29)
        Me.Buttontodos.TabIndex = 4
        Me.Buttontodos.Text = "MOSTRAR TODOS"
        Me.Buttontodos.UseVisualStyleBackColor = False
        '
        'Formbusquedahuesped
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(502, 541)
        Me.Controls.Add(Me.Buttontodos)
        Me.Controls.Add(Me.Buttoneliminar)
        Me.Controls.Add(Me.Buttonmodificar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Buttoncancelar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Formbusquedahuesped"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Búsqueda de Huespedes"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridViewLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxconsulta As System.Windows.Forms.TextBox
    Friend WithEvents Buttoncancelar As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxtel As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxdireccion As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxTD As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBoxnombre As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBoxemail As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxapellido As System.Windows.Forms.TextBox
    Friend WithEvents Buttonmodificar As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBoxciudad As System.Windows.Forms.TextBox
    Friend WithEvents Buttoneliminar As System.Windows.Forms.Button
    Friend WithEvents DataGridViewLista As System.Windows.Forms.DataGridView
    Friend WithEvents TextBoxND As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBoxsexo As System.Windows.Forms.TextBox
    Friend WithEvents Buttontodos As System.Windows.Forms.Button
End Class
