﻿Public Class FormMenuinicio

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub NUEVOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUEVOToolStripMenuItem.Click
        FormAltahuesped.Show()

    End Sub

    Private Sub BUSCARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCARToolStripMenuItem1.Click
        Formbusquedahab.Show()


    End Sub

    Private Sub NUEVOToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUEVOToolStripMenuItem2.Click
        Formaltareserva.Show()

    End Sub

    Private Sub NUEVOToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUEVOToolStripMenuItem1.Click
        Formaltahabitaciones.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        FormIN.Show()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        FormOUT.Show()


    End Sub

    Private Sub BUSCARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCARToolStripMenuItem.Click
        Formbusquedahuesped.Show()

    End Sub

    Private Sub BUSCARToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCARToolStripMenuItem2.Click
        FormMByBreservas.Show()

    End Sub

    Private Sub MODIFICARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MODIFICARToolStripMenuItem.Click
        Formmantenimientohabitacion.Show()

    End Sub

    Private Sub TIPODOCToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TIPODOCToolStripMenuItem.Click
        FormNacionalidades.Show()

    End Sub

    Private Sub CONSULTASToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CONSULTASToolStripMenuItem.Click
        FormConsultas.Show()

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub
End Class