﻿Imports MySql.Data.MySqlClient
Public Class FormMByBreservas
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT * FROM reservas where nro_doc ='" & TextBoxbusqueda.Text & "';"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewreservas.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try
        
    End Sub

    Private Sub Buttoncerrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncerrar.Click
        Me.Close()

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewreservas.CellContentClick

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub ButtonTR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonTR.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT count(*) FROM reservas"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewreservas.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub Buttoneliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoneliminar.Click
        Try
            Dim oConexion As New MySqlConnection(Cadena)
            Dim oSql As String
            Dim updatelib As String
            oConexion.Open()
            oSql = "DELETE FROM reservas WHERE idRESERVAS= " & TextBoxidreservas.Text & ""
            Dim oCommand As New MySqlCommand(oSql, oConexion)
            oCommand.ExecuteNonQuery()
            updatelib = "update habitaciones set reservado = 0 where Nro_hab =" & TextBoxNrohab.Text & ""
            Dim Commandlib As New MySqlCommand(updatelib, oConexion)
            Dim Adapterlib As New MySqlDataAdapter
            Adapterlib.SelectCommand = Commandlib
            Dim dbdatasetlib As New DataTable
            Adapterlib.Fill(dbdatasetlib)
            oConexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try
        MsgBox("se borrado un registro")

    End Sub

    Private Sub Buttonmodificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonmodificar.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxNrohab.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese un numero de habitacion"
            End If
            If IsNumeric(TextBoxNrohab.Text) Then
            Else
                Variable = False
                Mensaje = "porfavor ingrse el numero de la habitacion sin puntos ni guiones"
            End If
            If TextBoxND.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese un numero de habitacion"
            End If
            If IsNumeric(TextBoxND.Text) Then
            Else
                Variable = False
                Mensaje = "porfavor ingrse el documento sin puntos ni guiones"
            End If
            If TextBoxcambiar.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese un nuevo numero de habitacion"
            End If
            If Variable Then
                Dim rsOcupa As MySqlDataReader
                Dim ocupado As String = " select ocupado from habitaciones where Nro_Hab =" & TextBoxcambiar.Text & ""
                oConnexion.Open()
                Dim CommandSQL1 As New MySqlCommand(ocupado, oConnexion)
                Dim ocupado1 As Integer
                rsOcupa = CommandSQL1.ExecuteReader()
                rsOcupa.Read()
                ocupado1 = rsOcupa(0)
                oConnexion.Close()
                oConnexion.Open()
                Dim rsReserva As MySqlDataReader
                Dim reservado As String = " select reservado from habitaciones where Nro_Hab =" & TextBoxcambiar.Text & ""
                Dim CommandSQL2 As New MySqlCommand(reservado, oConnexion)
                Dim reservado1 As Integer
                rsReserva = CommandSQL2.ExecuteReader()
                rsReserva.Read()
                reservado1 = rsReserva(0)
                oConnexion.Close()
                If ocupado1 = 1 Then
                    MsgBox("habitacion ocupada porfavor ingrese otra")
                    TextBoxcambiar.Text = ""
                ElseIf reservado1 = 1 Then
                    MsgBox("habitacion reservada porfavor ingrese otra")
                    TextBoxcambiar.Text = ""
                Else
                    Dim updatesql As String
                    Dim updatelib As String
                    Dim updatereservar As String
                    oConnexion.Open()
                    updatelib = "update habitaciones set reservado = 0 where Nro_hab =" & TextBoxNrohab.Text & ""
                    Dim Commandlib As New MySqlCommand(updatelib, oConnexion)
                    Dim Adapterlib As New MySqlDataAdapter
                    Adapterlib.SelectCommand = Commandlib
                    Dim dbdatasetlib As New DataTable
                    Adapterlib.Fill(dbdatasetlib)
                    updatereservar = "update habitaciones set reservado = 1 where Nro_hab =" & TextBoxcambiar.Text & ""
                    Dim Commandreservas As New MySqlCommand(updatereservar, oConnexion)
                    Dim Adapterres As New MySqlDataAdapter
                    Adapterres.SelectCommand = Commandreservas
                    Dim dbdatasetres As New DataTable
                    Adapterres.Fill(dbdatasetres)
                    updatesql = "Update reservas Set Nro_Doc =" & TextBoxND.Text & " , Nro_hab =" & TextBoxcambiar.Text & " , fecha_entrada ='" & DateTimePickerreserva.Value & "' Where idRESERVAS =" & TextBoxidreservas.Text & ""
                    Dim CommandSQL As New MySqlCommand(updatesql, oConnexion)
                    Dim Adapterhpg As New MySqlDataAdapter
                    Adapterhpg.SelectCommand = CommandSQL
                    Dim dbdataset As New DataTable
                    Adapterhpg.Fill(dbdataset)
                    MsgBox("Modificacion exitosa")
                    TextBoxcambiar.Text = ""
                    TextBoxND.Text = ""
                    TextBoxNrohab.Text = ""
                    TextBoxidreservas.Text = ""
                    Dim ConsultaSqlref As String
                    ConsultaSqlref = "SELECT * FROM reservas"
                    Dim CommandSQL3 As New MySqlCommand(ConsultaSqlref, oConnexion)
                    Adapterhpg.SelectCommand = CommandSQL3
                    Adapterhpg.Fill(dbdataset)
                    DataGridViewreservas.DataSource = dbdataset
                    DataGridViewreservas.AllowUserToAddRows = False
                    oConnexion.Close()
                End If
            Else
                MsgBox(Mensaje)
                oConnexion.Close()
            End If
        Catch ex As Exception
            MsgBox("No se encontro la habitacion, porfavor ingrese otra!")

        End Try


    End Sub

    Private Sub DataGridViewreservas_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewreservas.CellClick
        Dim i As Integer
        Dim oConnexion As New MySqlConnection(Cadena)
        oConnexion.Open()
        i = DataGridViewreservas.CurrentRow.Index
        TextBoxidreservas.Text = DataGridViewreservas.Item(0, i).Value().ToString
        TextBoxND.Text = DataGridViewreservas.Item(1, i).Value().ToString
        TextBoxNrohab.Text = DataGridViewreservas.Item(2, i).Value().ToString
        DateTimePickerreserva.Value = DataGridViewreservas.Item(3, i).Value().ToString

        oConnexion.Close()

    End Sub

    Private Sub Buttontodas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttontodas.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            oConnexion.Open()
            ConsultaSql = "SELECT * FROM reservas"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewreservas.DataSource = dbdataset
            DataGridViewreservas.AllowUserToAddRows = False
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxcambiar.TextChanged

    End Sub
End Class