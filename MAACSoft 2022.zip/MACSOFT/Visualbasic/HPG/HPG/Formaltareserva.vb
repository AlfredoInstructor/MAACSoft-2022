﻿Imports MySql.Data.MySqlClient
Public Class Formaltareserva
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConexion As New MySqlConnection(Cadena)

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub Buttonreservar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonreservar.Click
        Try
            Dim rsexiste As MySqlDataReader
            Dim consultaex As String = " select count(*) from huespedes where Nro_Doc =" & TextBoxND.Text
            oConexion.Open()
            Dim Commandconsult As New MySqlCommand(consultaex, oConexion)
            Dim siExiste As Integer
            rsexiste = Commandconsult.ExecuteReader()
            rsexiste.Read()
            siExiste = rsexiste(0)
            oConexion.Close()

            Dim rsexiste1 As MySqlDataReader
            Dim consultaex1 As String = " select count(*) from habitaciones where Nro_hab =" & TextBoxnrohab.Text
            oConexion.Open()
            Dim Commandconsult1 As New MySqlCommand(consultaex1, oConexion)
            Dim siExiste1 As Integer
            rsexiste1 = Commandconsult1.ExecuteReader()
            rsexiste1.Read()
            siExiste1 = rsexiste1(0)
            oConexion.Close()

            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If Datatime1.Value = Today Then
                Variable = False
                Mensaje = "Error, ingrese una fecha"
            End If
            If TextBoxnrohab.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, ingrese una habitación"
            End If
            If TextBoxND.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, ingrese número de documento"
            End If
            If IsNumeric(TextBoxND.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese el documento sin puntos ni guiones"
            End If
            If Datatime1.Value > DateTime.Now.ToShortDateString() Then
            Else
                Variable = False
                Mensaje = "La fecha es anterior a la de hoy"
            End If

            If siExiste1 = 1 Then
                If siExiste = 1 Then
                    If Variable Then
                        oConexion.Open()

                        Dim rsOcupa As MySqlDataReader
                        Dim ocupado As String = " select ocupado from habitaciones where Nro_Hab =" & TextBoxnrohab.Text & ""
                        Dim CommandSQL1 As New MySqlCommand(ocupado, oConexion)
                        Dim ocupado1 As Integer
                        rsOcupa = CommandSQL1.ExecuteReader()
                        rsOcupa.Read()
                        ocupado1 = rsOcupa(0)
                        oConexion.Close()
                        oConexion.Open()
                        Dim rsReserva As MySqlDataReader
                        Dim reservado As String = " select reservado from habitaciones where Nro_Hab =" & TextBoxnrohab.Text & ""
                        Dim CommandSQL2 As New MySqlCommand(reservado, oConexion)
                        Dim reservado1 As Integer
                        rsReserva = CommandSQL2.ExecuteReader()
                        rsReserva.Read()
                        reservado1 = rsReserva(0)
                        oConexion.Close()
                        If ocupado1 = 1 Then
                            MsgBox("Habitación ocupada, porfavor ingrese otra")
                        ElseIf reservado1 = 1 Then
                            MsgBox("Habitación reservada porfavor ingrese otra")
                        Else
                            Dim updatesql As String = "Update habitaciones Set reservado = 1  Where Nro_hab =" & TextBoxnrohab.Text & ""
                            Dim CommandSQL As New MySqlCommand(updatesql, oConexion)

                            Dim oSql As String = "insert into reservas(Nro_Doc, Nro_hab, fecha_entrada) values(" & TextBoxND.Text & "," & TextBoxnrohab.Text & ",'" & Datatime1.Value & "')" 'DateTime.Now.ToShortDateString()
                            Dim oCommand As New MySqlCommand(oSql, oConexion)
                            oConexion.Open()
                            'ejecuta el insert:
                            oCommand.ExecuteNonQuery()
                            'ejecuta el update
                            CommandSQL.ExecuteNonQuery()
                            MsgBox("Reserva completada")
                        End If
                    Else
                        MsgBox(Mensaje)
                    End If
                Else
                    MsgBox("Número de documento no existe, ingrese otro o de alta de huésped")
                End If
            Else
                MsgBox("Número de habitación no existe, porfavor ingrese otra")
            End If

        Catch ex As Exception
            MsgBox("ERROR, intentelo de nuevo")
        End Try
    End Sub

    Private Sub Buttonnuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonnuevo.Click
        FormAltahuesped.Show()
    End Sub

    Private Sub ButtonBuscarhab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscarhab.Click
        Formbusquedahab.Show()
    End Sub

    Private Sub Datatime1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Datatime1.ValueChanged

    End Sub
End Class