﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formmantenimientohabitacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Buttoncancelar = New System.Windows.Forms.Button()
        Me.Buttonmodificar = New System.Windows.Forms.Button()
        Me.Buttonlista = New System.Windows.Forms.Button()
        Me.CheckBoxac = New System.Windows.Forms.CheckBox()
        Me.CheckBoxtv = New System.Windows.Forms.CheckBox()
        Me.CheckBoxvf = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxtcama = New System.Windows.Forms.TextBox()
        Me.Buttoneliminar = New System.Windows.Forms.Button()
        Me.CheckBoxfrig = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBoxNcama = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBoxNrohab = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBoxlista = New System.Windows.Forms.GroupBox()
        Me.DataGridViewlista = New System.Windows.Forms.DataGridView()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBoxlista.SuspendLayout()
        CType(Me.DataGridViewlista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.HPG.My.Resources.Resources._101913715
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(485, 529)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Buttoncancelar
        '
        Me.Buttoncancelar.Location = New System.Drawing.Point(388, 494)
        Me.Buttoncancelar.Name = "Buttoncancelar"
        Me.Buttoncancelar.Size = New System.Drawing.Size(75, 23)
        Me.Buttoncancelar.TabIndex = 19
        Me.Buttoncancelar.Text = "CANCELAR"
        Me.Buttoncancelar.UseVisualStyleBackColor = True
        '
        'Buttonmodificar
        '
        Me.Buttonmodificar.Location = New System.Drawing.Point(280, 193)
        Me.Buttonmodificar.Name = "Buttonmodificar"
        Me.Buttonmodificar.Size = New System.Drawing.Size(75, 23)
        Me.Buttonmodificar.TabIndex = 21
        Me.Buttonmodificar.Text = "MODIFICAR"
        Me.Buttonmodificar.UseVisualStyleBackColor = True
        '
        'Buttonlista
        '
        Me.Buttonlista.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Buttonlista.Location = New System.Drawing.Point(387, 285)
        Me.Buttonlista.Name = "Buttonlista"
        Me.Buttonlista.Size = New System.Drawing.Size(84, 39)
        Me.Buttonlista.TabIndex = 23
        Me.Buttonlista.Text = "LISTA"
        Me.Buttonlista.UseVisualStyleBackColor = False
        '
        'CheckBoxac
        '
        Me.CheckBoxac.AutoSize = True
        Me.CheckBoxac.Location = New System.Drawing.Point(167, 171)
        Me.CheckBoxac.Name = "CheckBoxac"
        Me.CheckBoxac.Size = New System.Drawing.Size(36, 17)
        Me.CheckBoxac.TabIndex = 34
        Me.CheckBoxac.Text = "SI"
        Me.CheckBoxac.UseVisualStyleBackColor = True
        '
        'CheckBoxtv
        '
        Me.CheckBoxtv.AutoSize = True
        Me.CheckBoxtv.Location = New System.Drawing.Point(168, 145)
        Me.CheckBoxtv.Name = "CheckBoxtv"
        Me.CheckBoxtv.Size = New System.Drawing.Size(36, 17)
        Me.CheckBoxtv.TabIndex = 31
        Me.CheckBoxtv.Text = "SI"
        Me.CheckBoxtv.UseVisualStyleBackColor = True
        '
        'CheckBoxvf
        '
        Me.CheckBoxvf.AutoSize = True
        Me.CheckBoxvf.Location = New System.Drawing.Point(168, 114)
        Me.CheckBoxvf.Name = "CheckBoxvf"
        Me.CheckBoxvf.Size = New System.Drawing.Size(36, 17)
        Me.CheckBoxvf.TabIndex = 25
        Me.CheckBoxvf.Text = "SI"
        Me.CheckBoxvf.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.DarkGray
        Me.Label7.Location = New System.Drawing.Point(15, 171)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 13)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "AIRE CONDICIONADO:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.DarkGray
        Me.GroupBox1.Controls.Add(Me.TextBoxtcama)
        Me.GroupBox1.Controls.Add(Me.Buttoneliminar)
        Me.GroupBox1.Controls.Add(Me.CheckBoxfrig)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Buttonmodificar)
        Me.GroupBox1.Controls.Add(Me.CheckBoxac)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.CheckBoxtv)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TextBoxNcama)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CheckBoxvf)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TextBoxNrohab)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 285)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(368, 232)
        Me.GroupBox1.TabIndex = 27
        Me.GroupBox1.TabStop = False
        '
        'TextBoxtcama
        '
        Me.TextBoxtcama.Location = New System.Drawing.Point(167, 70)
        Me.TextBoxtcama.Name = "TextBoxtcama"
        Me.TextBoxtcama.Size = New System.Drawing.Size(146, 20)
        Me.TextBoxtcama.TabIndex = 45
        '
        'Buttoneliminar
        '
        Me.Buttoneliminar.Location = New System.Drawing.Point(280, 161)
        Me.Buttoneliminar.Name = "Buttoneliminar"
        Me.Buttoneliminar.Size = New System.Drawing.Size(75, 23)
        Me.Buttoneliminar.TabIndex = 28
        Me.Buttoneliminar.Text = "ELIMINAR"
        Me.Buttoneliminar.UseVisualStyleBackColor = True
        '
        'CheckBoxfrig
        '
        Me.CheckBoxfrig.AutoSize = True
        Me.CheckBoxfrig.Location = New System.Drawing.Point(167, 197)
        Me.CheckBoxfrig.Name = "CheckBoxfrig"
        Me.CheckBoxfrig.Size = New System.Drawing.Size(36, 17)
        Me.CheckBoxfrig.TabIndex = 43
        Me.CheckBoxfrig.Text = "SI"
        Me.CheckBoxfrig.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.DarkGray
        Me.Label10.Location = New System.Drawing.Point(15, 197)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 13)
        Me.Label10.TabIndex = 42
        Me.Label10.Text = "FRIGOBAR:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.DarkGray
        Me.Label6.Location = New System.Drawing.Point(16, 145)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "TV COLOR:"
        '
        'TextBoxNcama
        '
        Me.TextBoxNcama.Location = New System.Drawing.Point(168, 42)
        Me.TextBoxNcama.Name = "TextBoxNcama"
        Me.TextBoxNcama.Size = New System.Drawing.Size(145, 20)
        Me.TextBoxNcama.TabIndex = 29
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.DarkGray
        Me.Label1.Location = New System.Drawing.Point(16, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 13)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "NUMERO DE CAMA"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.DarkGray
        Me.Label3.Location = New System.Drawing.Point(16, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "VENTANA AL FRENTE:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.DarkGray
        Me.Label2.Location = New System.Drawing.Point(16, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 13)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "TIPO DE CAMA"
        '
        'TextBoxNrohab
        '
        Me.TextBoxNrohab.Location = New System.Drawing.Point(168, 13)
        Me.TextBoxNrohab.Name = "TextBoxNrohab"
        Me.TextBoxNrohab.Size = New System.Drawing.Size(145, 20)
        Me.TextBoxNrohab.TabIndex = 22
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.DarkGray
        Me.Label5.Location = New System.Drawing.Point(15, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(147, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "NUMERO DE  HABITACION:"
        '
        'GroupBoxlista
        '
        Me.GroupBoxlista.Controls.Add(Me.DataGridViewlista)
        Me.GroupBoxlista.Location = New System.Drawing.Point(12, 12)
        Me.GroupBoxlista.Name = "GroupBoxlista"
        Me.GroupBoxlista.Size = New System.Drawing.Size(458, 267)
        Me.GroupBoxlista.TabIndex = 29
        Me.GroupBoxlista.TabStop = False
        Me.GroupBoxlista.Text = "Lista habitaciones"
        '
        'DataGridViewlista
        '
        Me.DataGridViewlista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewlista.Location = New System.Drawing.Point(6, 13)
        Me.DataGridViewlista.Name = "DataGridViewlista"
        Me.DataGridViewlista.Size = New System.Drawing.Size(445, 248)
        Me.DataGridViewlista.TabIndex = 0
        '
        'Formmantenimientohabitacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(485, 529)
        Me.Controls.Add(Me.GroupBoxlista)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Buttonlista)
        Me.Controls.Add(Me.Buttoncancelar)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Formmantenimientohabitacion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HABITACIONES"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBoxlista.ResumeLayout(False)
        CType(Me.DataGridViewlista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Buttoncancelar As System.Windows.Forms.Button
    Friend WithEvents Buttonmodificar As System.Windows.Forms.Button
    Friend WithEvents Buttonlista As System.Windows.Forms.Button
    Friend WithEvents CheckBoxac As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxtv As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxvf As System.Windows.Forms.CheckBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBoxNcama As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBoxNrohab As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Buttoneliminar As System.Windows.Forms.Button
    Friend WithEvents CheckBoxfrig As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBoxtcama As System.Windows.Forms.TextBox
    Friend WithEvents GroupBoxlista As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridViewlista As System.Windows.Forms.DataGridView
End Class
