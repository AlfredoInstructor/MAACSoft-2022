﻿Imports MySql.Data.MySqlClient
Public Class Formmantenimientohabitacion
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Buttonlista_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonlista.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String = "SELECT * FROM habitaciones"
            oConnexion.Open()
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Dim dbdataset As New DataTable
            Adapterhpg.SelectCommand = CommandSQL
            Adapterhpg.Fill(dbdataset)
            DataGridViewlista.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try

    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxtcama.TextChanged

    End Sub

    Private Sub DataGridViewlista_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewlista.CellClick
        Try
            Dim i As Integer
            i = DataGridViewlista.CurrentRow.Index
            TextBoxNrohab.Text = DataGridViewlista.Item(0, i).Value().ToString
            TextBoxNcama.Text = DataGridViewlista.Item(1, i).Value().ToString
            TextBoxtcama.Text = DataGridViewlista.Item(2, i).Value().ToString
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub Buttonbuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonlista.Click
        'Try
        'Dim oConexion As New MySqlConnection(Cadena)
        'Dim consultaSQL As String
        'consultaSQL = "SELECT nro_hab, nro_camas, tipo_de_cama FROM habitaciones WHERE Nro_hab ='" & TextBox2.Text & "';"
        'Dim commandSQL As New MySqlCommand(consultaSQL, oConexion)
        'Dim Rs As MySqlDataReader

        'commandSQL.Connection = oConexion
        'oConexion.Open()

        'Rs = commandSQL.ExecuteReader()

        'Rs.Read()
        'TextBoxNrohab.Text = Rs(0)
        'TextBoxNcama.Text = Rs(1)
        'TextBoxtcama.Text = Rs(2)
        'Rs.Close()
        'oConexion.Close()
        'Catch ex As Exception
        'MsgBox("error", ex.Message)
        'End Try
    End Sub

    Private Sub Buttoneliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoneliminar.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxNrohab.Text = String.Empty Then
                Variable = False
                Mensaje = "Ingrese el numero de habitación de cama"
            End If
            If IsNumeric(TextBoxNrohab.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese el numero de habitacion sin puntos ni guiones"
            End If

            If Variable Then
                Dim rsOcupa As MySqlDataReader
                Dim ocupado As String = " select ocupado from habitaciones where Nro_Hab =" & TextBoxNrohab.Text & ""
                Dim CommandSQL1 As New MySqlCommand(ocupado, oConnexion)
                Dim ocupado1 As Integer
                rsOcupa = CommandSQL1.ExecuteReader()
                rsOcupa.Read()
                ocupado1 = rsOcupa(0)
                oConnexion.Close()
                oConnexion.Open()
                Dim rsReserva As MySqlDataReader
                Dim reservado As String = " select reservado from habitaciones where Nro_Hab =" & TextBoxNrohab.Text & ""
                Dim CommandSQL2 As New MySqlCommand(reservado, oConnexion)
                Dim reservado1 As Integer
                rsReserva = CommandSQL2.ExecuteReader()
                rsReserva.Read()
                reservado1 = rsReserva(0)
                oConnexion.Close()
                oConnexion.Open()
                If ocupado1 = 1 Then
                    MsgBox("habitacion ocupada porfavor ingrese otra")
                ElseIf reservado1 = 1 Then
                    MsgBox("habitacion reservada porfavor ingrese otra")
                Else
                    Dim oSql As String
                    oSql = "DELETE FROM habitaciones WHERE Nro_Hab= " & TextBoxNrohab.Text & ""
                    Dim oCommand As New MySqlCommand(oSql, oConnexion)
                    oCommand.ExecuteNonQuery()
                    MsgBox("se borrado un registro")
                    oConnexion.Close()
                End If
            Else
                MsgBox(Mensaje)
                oConnexion.Close()
            End If

        Catch ex As Exception
            MsgBox("error")
        End Try

    End Sub

    Private Sub Buttonmodificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonmodificar.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim vf, tv, ac, fri As Integer
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If CheckBoxvf.Checked Then
                vf = 1
            Else
                vf = 0

            End If

            If CheckBoxtv.Checked Then
                tv = 1
            Else
                tv = 0
            End If

            If CheckBoxac.Checked Then
                ac = 1
            Else
                ac = 0
            End If

            If CheckBoxfrig.Checked Then
                fri = 1
            Else
                fri = 0
            End If
            If TextBoxtcama.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese un tipo de cama"
            End If
            If TextBoxNcama.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese el numero de cama"
            End If
            If IsNumeric(TextBoxNcama.Text) Then
            Else
                Variable = False
                Mensaje = "porfavor ingrse el numero de camas sin puntos ni guiones"
            End If
            If TextBoxNrohab.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese el numero de habitacion de cama"
            End If
            If IsNumeric(TextBoxNrohab.Text) Then
            Else
                Variable = False
                Mensaje = "porfavor ingrse el numero de habitacion sin puntos ni guiones"
            End If
            If Variable Then
                oConnexion.Open()
                Dim updatesql As String
                updatesql = "Update habitaciones  Set Nro_camas =" & TextBoxNcama.Text & " , tipo_de_cama ='" & TextBoxtcama.Text & "' , V_al_Frente =" & vf & " , AC =" & ac & " , Frigobar =" & fri & " , TVcolor =" & tv & " Where Nro_Hab =" & TextBoxNrohab.Text & ""
                Dim Adapterhpg As New MySqlDataAdapter
                Dim CommandSQL As New MySqlCommand(updatesql, oConnexion)
                Adapterhpg.SelectCommand = CommandSQL
                Dim dbdataset As New DataTable
                Adapterhpg.Fill(dbdataset)
                MsgBox("Modificacion exitosa")
                TextBoxNrohab.Text = ""
                TextBoxNcama.Text = ""
                TextBoxtcama.Text = ""
                Dim ConsultaSql As String = "SELECT * FROM habitaciones"
                Dim CommandSQL1 As New MySqlCommand(ConsultaSql, oConnexion)
                Adapterhpg.SelectCommand = CommandSQL1
                Adapterhpg.Fill(dbdataset)
                DataGridViewlista.DataSource = dbdataset
                oConnexion.Close()
            Else
                MsgBox(Mensaje)
            End If
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub
End Class