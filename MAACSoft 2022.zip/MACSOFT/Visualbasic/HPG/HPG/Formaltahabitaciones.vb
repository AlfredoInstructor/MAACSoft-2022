﻿Imports MySql.Data.MySqlClient
Public Class Formaltahabitaciones
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConexion As New MySqlConnection(Cadena)
    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Buttoncancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub Buttonguardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonguardar.Click
        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""

            If TextBoxtipoc.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, ingrese tipo de cama"
            End If
            If TextBoxcantidad.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, ingrese cantidad de camas"
            End If
            If TextBoxNrohab.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, ingrese una habitación"
            End If
            If IsNumeric(TextBoxcantidad.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese la cantidad de camas sin puntos ni guiones"
            End If
            If IsNumeric(TextBoxNrohab.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese el numero de habitacion sin puntos ni guiones"
            End If
            If Variable Then
                Dim vf, tv, ac, fri As Integer
                oConexion.Open()
                If CheckBoxVF.Checked Then
                    vf = 1
                Else
                    vf = 0

                End If

                If CheckBoxTV.Checked Then
                    tv = 1
                Else
                    tv = 0
                End If

                If CheckBoxAC.Checked Then
                    ac = 1
                Else
                    ac = 0
                End If

                If CheckBoxfrig.Checked Then
                    fri = 1
                Else
                    fri = 0
                End If



                Dim oSql As String = "insert into habitaciones(Nro_Hab, Nro_camas, tipo_de_cama, V_al_Frente, AC, Frigobar, TVcolor, Ocupado, Reservado) values(" & TextBoxNrohab.Text & ",'" & TextBoxcantidad.Text & "','" & TextBoxtipoc.Text & "'," & vf & "," & ac & "," & fri & "," & tv & ",   0  ,  0 )"
                Dim oCommand As New MySqlCommand(oSql, oConexion)

                oCommand.ExecuteNonQuery()

                MsgBox("habitacion agregada")
                Me.Close()
            Else
                Variable = False
                MsgBox(Mensaje)
            End If
        Catch ex As Exception
            MsgBox("Numero habitacion existente porfavor ingrese otro")
            oConexion.Close()

        End Try
    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class