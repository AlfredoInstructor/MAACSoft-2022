﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMenuinicio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMenuinicio))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HUESPEDESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NUEVOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BUSCARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HABITACIONESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NUEVOToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BUSCARToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MODIFICARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RESERVASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NUEVOToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BUSCARToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIPODOCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CONSULTASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.BurlyWood
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HUESPEDESToolStripMenuItem, Me.HABITACIONESToolStripMenuItem, Me.RESERVASToolStripMenuItem, Me.TIPODOCToolStripMenuItem, Me.CONSULTASToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(680, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HUESPEDESToolStripMenuItem
        '
        Me.HUESPEDESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NUEVOToolStripMenuItem, Me.BUSCARToolStripMenuItem})
        Me.HUESPEDESToolStripMenuItem.Name = "HUESPEDESToolStripMenuItem"
        Me.HUESPEDESToolStripMenuItem.Size = New System.Drawing.Size(81, 20)
        Me.HUESPEDESToolStripMenuItem.Text = "HUESPEDES"
        '
        'NUEVOToolStripMenuItem
        '
        Me.NUEVOToolStripMenuItem.Name = "NUEVOToolStripMenuItem"
        Me.NUEVOToolStripMenuItem.Size = New System.Drawing.Size(220, 22)
        Me.NUEVOToolStripMenuItem.Text = "NUEVO"
        '
        'BUSCARToolStripMenuItem
        '
        Me.BUSCARToolStripMenuItem.Name = "BUSCARToolStripMenuItem"
        Me.BUSCARToolStripMenuItem.Size = New System.Drawing.Size(220, 22)
        Me.BUSCARToolStripMenuItem.Text = "BUSCAR/MANTENIMIENTO"
        '
        'HABITACIONESToolStripMenuItem
        '
        Me.HABITACIONESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NUEVOToolStripMenuItem1, Me.BUSCARToolStripMenuItem1, Me.MODIFICARToolStripMenuItem})
        Me.HABITACIONESToolStripMenuItem.Name = "HABITACIONESToolStripMenuItem"
        Me.HABITACIONESToolStripMenuItem.Size = New System.Drawing.Size(101, 20)
        Me.HABITACIONESToolStripMenuItem.Text = "HABITACIONES"
        '
        'NUEVOToolStripMenuItem1
        '
        Me.NUEVOToolStripMenuItem1.Name = "NUEVOToolStripMenuItem1"
        Me.NUEVOToolStripMenuItem1.Size = New System.Drawing.Size(195, 22)
        Me.NUEVOToolStripMenuItem1.Text = "NUEVO"
        '
        'BUSCARToolStripMenuItem1
        '
        Me.BUSCARToolStripMenuItem1.Name = "BUSCARToolStripMenuItem1"
        Me.BUSCARToolStripMenuItem1.Size = New System.Drawing.Size(195, 22)
        Me.BUSCARToolStripMenuItem1.Text = "BUSCAR"
        '
        'MODIFICARToolStripMenuItem
        '
        Me.MODIFICARToolStripMenuItem.Name = "MODIFICARToolStripMenuItem"
        Me.MODIFICARToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.MODIFICARToolStripMenuItem.Text = "MODIFICAR/ELIMINAR"
        '
        'RESERVASToolStripMenuItem
        '
        Me.RESERVASToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NUEVOToolStripMenuItem2, Me.BUSCARToolStripMenuItem2})
        Me.RESERVASToolStripMenuItem.Name = "RESERVASToolStripMenuItem"
        Me.RESERVASToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.RESERVASToolStripMenuItem.Text = "RESERVAS"
        '
        'NUEVOToolStripMenuItem2
        '
        Me.NUEVOToolStripMenuItem2.Name = "NUEVOToolStripMenuItem2"
        Me.NUEVOToolStripMenuItem2.Size = New System.Drawing.Size(220, 22)
        Me.NUEVOToolStripMenuItem2.Text = "NUEVO"
        '
        'BUSCARToolStripMenuItem2
        '
        Me.BUSCARToolStripMenuItem2.Name = "BUSCARToolStripMenuItem2"
        Me.BUSCARToolStripMenuItem2.Size = New System.Drawing.Size(220, 22)
        Me.BUSCARToolStripMenuItem2.Text = "BUSCAR/MANTENIMIENTO"
        '
        'TIPODOCToolStripMenuItem
        '
        Me.TIPODOCToolStripMenuItem.Name = "TIPODOCToolStripMenuItem"
        Me.TIPODOCToolStripMenuItem.Size = New System.Drawing.Size(151, 20)
        Me.TIPODOCToolStripMenuItem.Text = "TIPOS DE DOCUMENTOS"
        '
        'CONSULTASToolStripMenuItem
        '
        Me.CONSULTASToolStripMenuItem.Name = "CONSULTASToolStripMenuItem"
        Me.CONSULTASToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.CONSULTASToolStripMenuItem.Text = "CONSULTAS"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.SlateGray
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(584, 356)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "SALIR"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.PowderBlue
        Me.Button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.Location = New System.Drawing.Point(34, 73)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(120, 23)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "CHECK-IN"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.LightSalmon
        Me.Button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.Location = New System.Drawing.Point(34, 129)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(120, 23)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "CHECK-OUT"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.HPG.My.Resources.Resources.lobby_casa_gangotena
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(680, 367)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'FormMenuinicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(680, 391)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormMenuinicio"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HOTEL PARTHENON GOLDEN"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HUESPEDESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BUSCARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NUEVOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HABITACIONESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BUSCARToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NUEVOToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RESERVASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BUSCARToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NUEVOToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents MODIFICARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIPODOCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CONSULTASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
