﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormConsultas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBoxconsulta = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ButtonBuscarR = New System.Windows.Forms.Button()
        Me.DGVconsultas = New System.Windows.Forms.DataGridView()
        Me.Buttonbuscari = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBoxconsulta2 = New System.Windows.Forms.TextBox()
        Me.ButtonBuscar = New System.Windows.Forms.Button()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        CType(Me.DGVconsultas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBoxconsulta
        '
        Me.TextBoxconsulta.Location = New System.Drawing.Point(110, 22)
        Me.TextBoxconsulta.Name = "TextBoxconsulta"
        Me.TextBoxconsulta.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxconsulta.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Numero Habitacion"
        '
        'ButtonBuscarR
        '
        Me.ButtonBuscarR.Location = New System.Drawing.Point(69, 48)
        Me.ButtonBuscarR.Name = "ButtonBuscarR"
        Me.ButtonBuscarR.Size = New System.Drawing.Size(141, 23)
        Me.ButtonBuscarR.TabIndex = 2
        Me.ButtonBuscarR.Text = "BUSCAR RESPONSABLE"
        Me.ButtonBuscarR.UseVisualStyleBackColor = True
        '
        'DGVconsultas
        '
        Me.DGVconsultas.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DGVconsultas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVconsultas.Location = New System.Drawing.Point(12, 136)
        Me.DGVconsultas.Name = "DGVconsultas"
        Me.DGVconsultas.Size = New System.Drawing.Size(501, 150)
        Me.DGVconsultas.TabIndex = 3
        '
        'Buttonbuscari
        '
        Me.Buttonbuscari.Location = New System.Drawing.Point(69, 77)
        Me.Buttonbuscari.Name = "Buttonbuscari"
        Me.Buttonbuscari.Size = New System.Drawing.Size(141, 23)
        Me.Buttonbuscari.TabIndex = 4
        Me.Buttonbuscari.Text = "BUSCAR INTEGRANTES"
        Me.Buttonbuscari.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Buttonbuscari)
        Me.GroupBox1.Controls.Add(Me.TextBoxconsulta)
        Me.GroupBox1.Controls.Add(Me.ButtonBuscarR)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(231, 116)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Buscar por:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.TextBoxconsulta2)
        Me.GroupBox2.Controls.Add(Me.ButtonBuscar)
        Me.GroupBox2.Location = New System.Drawing.Point(249, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(264, 55)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Buscar por:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Fecha:"
        '
        'TextBoxconsulta2
        '
        Me.TextBoxconsulta2.Location = New System.Drawing.Point(52, 18)
        Me.TextBoxconsulta2.Name = "TextBoxconsulta2"
        Me.TextBoxconsulta2.Size = New System.Drawing.Size(125, 20)
        Me.TextBoxconsulta2.TabIndex = 0
        '
        'ButtonBuscar
        '
        Me.ButtonBuscar.Location = New System.Drawing.Point(183, 16)
        Me.ButtonBuscar.Name = "ButtonBuscar"
        Me.ButtonBuscar.Size = New System.Drawing.Size(75, 23)
        Me.ButtonBuscar.TabIndex = 2
        Me.ButtonBuscar.Text = "BUSCAR"
        Me.ButtonBuscar.UseVisualStyleBackColor = True
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.Location = New System.Drawing.Point(438, 292)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.ButtonCancelar.TabIndex = 7
        Me.ButtonCancelar.Text = "CANCELAR"
        Me.ButtonCancelar.UseVisualStyleBackColor = True
        '
        'FormConsultas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.ClientSize = New System.Drawing.Size(527, 321)
        Me.Controls.Add(Me.ButtonCancelar)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DGVconsultas)
        Me.Name = "FormConsultas"
        Me.Text = "Consultas"
        CType(Me.DGVconsultas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TextBoxconsulta As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ButtonBuscarR As System.Windows.Forms.Button
    Friend WithEvents DGVconsultas As System.Windows.Forms.DataGridView
    Friend WithEvents Buttonbuscari As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBoxconsulta2 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonBuscar As System.Windows.Forms.Button
    Friend WithEvents ButtonCancelar As System.Windows.Forms.Button
End Class
