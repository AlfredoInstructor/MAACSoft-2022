﻿Imports MySql.Data.MySqlClient
Public Class FormConsultas
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConnexion As New MySqlConnection(Cadena)
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub ButtonBuscarR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscarR.Click
        Try
            Dim Verification As Boolean = True
            Dim Mensaje As String = ""

            If TextBoxconsulta.Text = String.Empty Then
                Verification = False
                Mensaje = "ingrese un numer de documento"
            End If
            If IsNumeric(TextBoxconsulta.Text) Then
            Else
                Verification = False
                Mensaje = "porfavor ingrese el numero de documento sin puntos ni guiones"
            End If
            If Verification Then
                Dim oConnexion As New MySqlConnection(Cadena)
                Dim ConsultaSql As String = "SELECT h.Nombre, h.Apellido, h.Nro_Doc, i.Fecha_entrada, i.Fecha_salida , i.Total_pagar, i.idHISTORIAL FROM huespedes h, historial i WHERE h.Nro_Doc = i.Nro_Doc AND Nro_hab ='" & TextBoxconsulta.Text & "'"
                Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
                Dim Adapterhpg As New MySqlDataAdapter
                Adapterhpg.SelectCommand = CommandSQL
                Dim dbdataset As New DataTable
                Adapterhpg.Fill(dbdataset)
                DGVconsultas.DataSource = dbdataset
            Else
                MsgBox(Mensaje)
            End If
        Catch ex As Exception
            MsgBox("ingrese otro numero de habitacion")
            TextBoxconsulta.Text = ""
            oConnexion.Close()

        End Try
    End Sub

    Private Sub Buttonbuscari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonbuscari.Click
        Try
            Dim Verification As Boolean = True
            Dim Mensaje As String = ""

            If TextBoxconsulta.Text = String.Empty Then
                Verification = False
                Mensaje = "ingrese un numer de documento"
            End If
            If IsNumeric(TextBoxconsulta.Text) Then
            Else
                Verification = False
                Mensaje = "porfavor ingrese el numero de documento sin puntos ni guiones"
            End If
            If Verification Then
                Dim oConnexion As New MySqlConnection(Cadena)
                Dim ConsultaSql As String = "SELECT i.idhistorial, h.Nombre, h.Apellido, h.Nro_Doc, i.Fecha_entrada, i.Fecha_salida , i.Total_pagar FROM huespedes h, historial i, Ocupan a WHERE h.Nro_Doc = a.Nro_Doc AND i.idHistorial = a.idHistorial AND Nro_hab =" & TextBoxconsulta.Text

                Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
                Dim Adapterhpg As New MySqlDataAdapter
                Adapterhpg.SelectCommand = CommandSQL
                Dim dbdataset As New DataTable
                Adapterhpg.Fill(dbdataset)
                DGVconsultas.DataSource = dbdataset
            Else
                MsgBox(Mensaje)
            End If
        Catch ex As Exception
            TextBoxconsulta.Text = ""
            MsgBox("ingrese un numero de habitacion")
            oConnexion.Close()

        End Try
    End Sub

    Private Sub ButtonBuscarfecha_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String = "SELECT h.Nombre, h.Apellido, h.Nro_Doc, i.Nro_Hab FROM huespedes h, historial i, Ocupan a WHERE i.idHISTORIAL = a.idHISTORIAL AND a.nro_doc = h.nro_doc AND CAST(Fecha_entrada AS DATE) ='" & TextBoxconsulta2.Text & "'"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DGVconsultas.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("No existe datos para esa fecha, porfavor ingrese otra fecha ")
            TextBoxconsulta2.Text = ""
            oConnexion.Close()

        End Try
    End Sub

    Private Sub FormConsultas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click

        Me.Close()
    End Sub
End Class