﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormIN
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBoxNrohab = New System.Windows.Forms.TextBox()
        Me.Buttonaceptar = New System.Windows.Forms.Button()
        Me.TextBoxNrodocresp = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Buttoncancelar = New System.Windows.Forms.Button()
        Me.TextBoxResp = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BUSCAR = New System.Windows.Forms.Button()
        Me.DGVRESP = New System.Windows.Forms.DataGridView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TextBoxID = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxdoc = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ButtonTODOS = New System.Windows.Forms.Button()
        Me.Buttonnuevo = New System.Windows.Forms.Button()
        Me.ButtonHab = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DGVRESP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightSlateGray
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 183)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(454, 138)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.PowderBlue
        Me.GroupBox2.Controls.Add(Me.ButtonHab)
        Me.GroupBox2.Controls.Add(Me.TextBoxNrohab)
        Me.GroupBox2.Controls.Add(Me.Buttonaceptar)
        Me.GroupBox2.Controls.Add(Me.TextBoxNrodocresp)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 19)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(433, 97)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "RESPONSABLE"
        '
        'TextBoxNrohab
        '
        Me.TextBoxNrohab.Location = New System.Drawing.Point(129, 50)
        Me.TextBoxNrohab.Name = "TextBoxNrohab"
        Me.TextBoxNrohab.Size = New System.Drawing.Size(175, 20)
        Me.TextBoxNrohab.TabIndex = 4
        '
        'Buttonaceptar
        '
        Me.Buttonaceptar.Location = New System.Drawing.Point(343, 74)
        Me.Buttonaceptar.Name = "Buttonaceptar"
        Me.Buttonaceptar.Size = New System.Drawing.Size(75, 23)
        Me.Buttonaceptar.TabIndex = 1
        Me.Buttonaceptar.Text = "ACEPTAR"
        Me.Buttonaceptar.UseVisualStyleBackColor = True
        '
        'TextBoxNrodocresp
        '
        Me.TextBoxNrodocresp.Location = New System.Drawing.Point(130, 16)
        Me.TextBoxNrodocresp.Name = "TextBoxNrodocresp"
        Me.TextBoxNrodocresp.Size = New System.Drawing.Size(174, 20)
        Me.TextBoxNrodocresp.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(7, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nro Habitacion:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nro Documento"
        '
        'Buttoncancelar
        '
        Me.Buttoncancelar.Location = New System.Drawing.Point(373, 463)
        Me.Buttoncancelar.Name = "Buttoncancelar"
        Me.Buttoncancelar.Size = New System.Drawing.Size(75, 23)
        Me.Buttoncancelar.TabIndex = 0
        Me.Buttoncancelar.Text = "CANCELAR"
        Me.Buttoncancelar.UseVisualStyleBackColor = True
        '
        'TextBoxResp
        '
        Me.TextBoxResp.Location = New System.Drawing.Point(191, 9)
        Me.TextBoxResp.Name = "TextBoxResp"
        Me.TextBoxResp.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxResp.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(179, 18)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Documento responsable"
        '
        'BUSCAR
        '
        Me.BUSCAR.Location = New System.Drawing.Point(297, 7)
        Me.BUSCAR.Name = "BUSCAR"
        Me.BUSCAR.Size = New System.Drawing.Size(61, 23)
        Me.BUSCAR.TabIndex = 3
        Me.BUSCAR.Text = "BUSCAR"
        Me.BUSCAR.UseVisualStyleBackColor = True
        '
        'DGVRESP
        '
        Me.DGVRESP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVRESP.Location = New System.Drawing.Point(6, 40)
        Me.DGVRESP.Name = "DGVRESP"
        Me.DGVRESP.Size = New System.Drawing.Size(454, 137)
        Me.DGVRESP.TabIndex = 7
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightSlateGray
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 327)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(454, 134)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.PowderBlue
        Me.GroupBox4.Controls.Add(Me.TextBoxID)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.TextBoxdoc)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Location = New System.Drawing.Point(15, 19)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(433, 97)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "OCUPAN:"
        '
        'TextBoxID
        '
        Me.TextBoxID.Location = New System.Drawing.Point(38, 15)
        Me.TextBoxID.Name = "TextBoxID"
        Me.TextBoxID.Size = New System.Drawing.Size(222, 20)
        Me.TextBoxID.TabIndex = 4
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(352, 74)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "ACEPTAR"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(7, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(25, 18)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "ID"
        '
        'TextBoxdoc
        '
        Me.TextBoxdoc.Location = New System.Drawing.Point(130, 47)
        Me.TextBoxdoc.Name = "TextBoxdoc"
        Me.TextBoxdoc.Size = New System.Drawing.Size(130, 20)
        Me.TextBoxdoc.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(7, 47)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(117, 18)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Nro Documento"
        '
        'ButtonTODOS
        '
        Me.ButtonTODOS.Location = New System.Drawing.Point(387, 6)
        Me.ButtonTODOS.Name = "ButtonTODOS"
        Me.ButtonTODOS.Size = New System.Drawing.Size(61, 23)
        Me.ButtonTODOS.TabIndex = 8
        Me.ButtonTODOS.Text = "TODOS"
        Me.ButtonTODOS.UseVisualStyleBackColor = True
        '
        'Buttonnuevo
        '
        Me.Buttonnuevo.Location = New System.Drawing.Point(12, 467)
        Me.Buttonnuevo.Name = "Buttonnuevo"
        Me.Buttonnuevo.Size = New System.Drawing.Size(134, 23)
        Me.Buttonnuevo.TabIndex = 5
        Me.Buttonnuevo.Text = "Registrar nuevo huesped"
        Me.Buttonnuevo.UseVisualStyleBackColor = True
        '
        'ButtonHab
        '
        Me.ButtonHab.Location = New System.Drawing.Point(319, 45)
        Me.ButtonHab.Name = "ButtonHab"
        Me.ButtonHab.Size = New System.Drawing.Size(108, 23)
        Me.ButtonHab.TabIndex = 9
        Me.ButtonHab.Text = "buscar habitacion"
        Me.ButtonHab.UseVisualStyleBackColor = True
        '
        'FormIN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(472, 498)
        Me.Controls.Add(Me.Buttonnuevo)
        Me.Controls.Add(Me.ButtonTODOS)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.DGVRESP)
        Me.Controls.Add(Me.Buttoncancelar)
        Me.Controls.Add(Me.BUSCAR)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBoxResp)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FormIN"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CHECK-IN"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DGVRESP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Buttonaceptar As System.Windows.Forms.Button
    Friend WithEvents Buttoncancelar As System.Windows.Forms.Button
    Friend WithEvents TextBoxNrohab As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxNrodocresp As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxResp As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BUSCAR As System.Windows.Forms.Button
    Friend WithEvents DGVRESP As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxID As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxdoc As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ButtonTODOS As System.Windows.Forms.Button
    Friend WithEvents Buttonnuevo As System.Windows.Forms.Button
    Friend WithEvents ButtonHab As System.Windows.Forms.Button
End Class
