﻿Imports MySql.Data.MySqlClient
Public Class Formbusquedahab
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConnexion As New MySqlConnection(Cadena)

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()

    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        oConnexion.Close()
        Me.Close()

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewhabitaciones.CellContentClick

    End Sub



    Private Sub Buttoncdisponibles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncdisponible.Click

        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT count(*) FROM habitaciones WHERE ocupado=0 "

            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub Buttonocupadas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonocupadas.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT count(*) FROM habitaciones WHERE ocupado=1 "

            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try

    End Sub

    Private Sub ButtonLtotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonLtotal.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT * FROM habitaciones "

            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Form9_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Buttonldisponible_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonldisponible.Click

        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT * FROM habitaciones WHERE ocupado=0 "

            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub Buttonreservas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonreservas.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            ConsultaSql = "SELECT * FROM habitaciones WHERE reservado=1 "

            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GroupBox3_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GroupBox4_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub CheckBox4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RadioButton2_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Buttonbuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonbuscar.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim Consulta As String

            Consulta = ""

            If RB1.Checked Then
                Consulta = "SELECT * FROM habitaciones WHERE Nro_hab ='" & TextBox1.Text & "';"

            ElseIf RB2.Checked Then
                Consulta = "SELECT i.Nro_Doc, i.Nro_hab, i.Fecha_entrada FROM historial i, habitaciones a WHERE i.nro_hab = a.nro_hab AND a.ocupado = '1' AND Fecha_salida is null AND i.Nro_Doc ='" & TextBox1.Text & "';"
            End If

            Dim CommandSQL As New MySqlCommand(Consulta, oConnexion)
            oConnexion.Open()
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset

        Catch ex As MySqlException
            MsgBox("Seleccione una opción")
            oConnexion.Close()

        End Try
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2C.CheckedChanged

    End Sub

    Private Sub ButtonBR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBR.Click

        Try
            Dim oConexion As New MySqlConnection(Cadena)
            Dim tv, fri, ac, vf, cama As Integer
            Dim Consulta As String

            If CheckBox1C.Checked Then
                cama = 1
            Else
                cama = 2
            End If

            If CheckBoxTV.Checked Then
                tv = 1
            Else
                tv = 0
            End If

            If CheckBoxAC.Checked Then
                ac = 1
            Else
                ac = 0
            End If

            If CheckBoxFRI.Checked Then
                fri = 1
            Else
                fri = 0
            End If

            If CheckBoxVF.Checked Then
                vf = 1
            Else
                vf = 0
            End If
            oConexion.Open()

            Consulta = "SELECT * FROM habitaciones WHERE Nro_camas =" & cama & " AND V_al_Frente =" & vf & " AND AC =" & ac & " AND Frigobar=" & fri & " AND TVcolor =" & tv & " AND Ocupado = 0 AND Reservado = 0"
            Dim CommandSQL As New MySqlCommand(Consulta, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewhabitaciones.DataSource = dbdataset
        Catch ex As Exception
            MsgBox("Error")
            oConnexion.Close()

        End Try
    End Sub
End Class