﻿Imports MySql.Data.MySqlClient
Public Class FormAltahuesped
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConexion As New MySqlConnection(Cadena)

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label8_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label9.Click

    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxdireccion.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonagregar.Click
        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxEmail.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Email"
            End If
            If TextBoxTelefono.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Teléfono"
            End If
            If TextBoxdireccion.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Dirección"
            End If
            If TextBoxCiudad.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Ciudad de origen"
            End If
            If TextBoxTD.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Tipo documento"
            End If
            If TextBoxND.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Número Documento"
            End If
            If TextBoxApellido.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Apellido"
            End If
            If IsNumeric(TextBoxND.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese el numero de documento sin puntos ni guiones"
            End If
            If TextBoxNombre.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar Campo Nombre"
            End If
           
            If Variable Then
                If (RB1.Checked) Then

                    Dim oSql As String = "insert into huespedes(Nro_Doc, Nombre, Apellido, Dirección, Telefono, Email, sexo, Tipo_Doc, Ciudad_origen) values(" & TextBoxND.Text & ",'" & TextBoxNombre.Text & "','" & TextBoxApellido.Text & "','" & TextBoxdireccion.Text & "','" & TextBoxTelefono.Text & "','" & TextBoxEmail.Text & "', ' hombre ', '" & TextBoxTD.Text & "', '" & TextBoxCiudad.Text & "')"
                    Dim oCommand As New MySqlCommand(oSql, oConexion)
                    oConexion.Open()
                    oCommand.ExecuteNonQuery()
                Else
                    Dim oSql As String = "insert into huespedes(Nro_Doc, Nombre, Apellido, Dirección, Telefono, Email, sexo, Tipo_Doc, Ciudad_origen) values(" & TextBoxND.Text & ",'" & TextBoxNombre.Text & "','" & TextBoxApellido.Text & "','" & TextBoxdireccion.Text & "','" & TextBoxTelefono.Text & "','" & TextBoxEmail.Text & "', ' Mujer ', '" & TextBoxTD.Text & "', '" & TextBoxCiudad.Text & "')"
                    Dim oCommand As New MySqlCommand(oSql, oConexion)
                    oConexion.Open()
                    oCommand.ExecuteNonQuery()
                End If
                MsgBox("Huésped Agregado")
                TextBoxEmail.Text = ""
                TextBoxNombre.Text = ""
                TextBoxApellido.Text = ""
                TextBoxCiudad.Text = ""
                TextBoxTD.Text = ""
                TextBoxND.Text = ""
                TextBoxTelefono.Text = ""
                TextBoxdireccion.Text = ""
                oConexion.Close()
            Else
                MsgBox(Mensaje)
            End If

        Catch ex As Exception
            MsgBox("Tipo documento no existe, vuelva a intentar")
            TextBoxTD.Text = ""
            oConexion.Close()
        End Try
    End Sub

    Private Sub Buttonver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonver.Click
        FormNacionalidades.Show()
    End Sub
End Class