﻿Imports MySql.Data.MySqlClient
Public Class Formbusquedahuesped
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConnexion As New MySqlConnection(Cadena)

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Buttoncancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub GroupBox3_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Form8_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Buttonmodificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonmodificar.Click

        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxND.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Número Documento"
            End If
            If IsNumeric(TextBoxND.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese el documento sin puntos ni guiones"
            End If
            If Variable Then
                Dim updatesql As String
                updatesql = "Update huespedes Set Tipo_Doc = '" & TextBoxTD.Text & "', Nombre ='" & TextBoxnombre.Text & "' , Apellido ='" & TextBoxapellido.Text & "' , Dirección ='" & TextBoxdireccion.Text & "' , Telefono ='" & TextBoxtel.Text & "' , Email ='" & TextBoxemail.Text & "' , Sexo ='" & TextBoxsexo.Text & "' , Ciudad_origen='" & TextBoxciudad.Text & "' Where Nro_Doc =" & TextBoxND.Text & ""
                Dim Adapterhpg As New MySqlDataAdapter
                Dim CommandSQL As New MySqlCommand(updatesql, oConnexion)
                Adapterhpg.SelectCommand = CommandSQL
                Dim dbdataset As New DataTable
                Adapterhpg.Fill(dbdataset)
                MsgBox("Modificacion exitosa")
                TextBoxND.Text = ""
                TextBoxTD.Text = ""
                TextBoxnombre.Text = ""
                TextBoxapellido.Text = ""
                TextBoxdireccion.Text = ""
                TextBoxtel.Text = ""
                TextBoxemail.Text = ""
                TextBoxsexo.Text = ""
                TextBoxciudad.Text = ""
                oConnexion.Close()
                Dim ConsultaSql As String = "SELECT * FROM huespedes ORDER BY Nombre ASC"
                Dim CommandSQL1 As New MySqlCommand(ConsultaSql, oConnexion)
                Adapterhpg.SelectCommand = CommandSQL1
                Adapterhpg.Fill(dbdataset)
                DataGridViewLista.DataSource = dbdataset
                oConnexion.Close()
            Else
                MsgBox(Mensaje)
                oConnexion.Close()
            End If
        Catch ex As Exception
            MsgBox("Error")

        End Try
    End Sub

    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub DataGridViewLista_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewLista.CellContentClick
        
    End Sub

    Private Sub Buttoneliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoneliminar.Click

        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxND.Text = String.Empty Then
                Variable = False
                Mensaje = "Error, rellenar campo Número Documento"
            End If
            If IsNumeric(TextBoxND.Text) Then
            Else
                Variable = False
                Mensaje = "Porfavor ingrese el documento sin puntos ni guiones"
            End If

            If Variable Then
                Dim oConexion As New MySqlConnection(Cadena)
                Dim oSql As String
                oConexion.Open()
                oSql = "DELETE FROM huespedes WHERE Nro_Doc= " & TextBoxND.Text & ""
                Dim oCommand As New MySqlCommand(oSql, oConexion)
                oCommand.ExecuteNonQuery()
                MsgBox("Se borrado un registro")
                TextBoxND.Text = ""
                TextBoxTD.Text = ""
                TextBoxnombre.Text = ""
                TextBoxapellido.Text = ""
                TextBoxdireccion.Text = ""
                TextBoxtel.Text = ""
                TextBoxemail.Text = ""
                TextBoxsexo.Text = ""
                TextBoxciudad.Text = ""
                oConnexion.Close()
                oConnexion.Open()

                Dim ConsultaSql As String = "SELECT * FROM huespedes ORDER BY Nombre ASC"
                Dim CommandSQL1 As New MySqlCommand(ConsultaSql, oConnexion)
                Dim Adapterhpg As New MySqlDataAdapter
                Adapterhpg.SelectCommand = CommandSQL1
                Dim dbdataset As New DataTable
                Adapterhpg.Fill(dbdataset)
                DataGridViewLista.DataSource = dbdataset
                oConnexion.Close()
            Else
                MsgBox(Mensaje)
                oConnexion.Close()
            End If
        Catch ex As Exception
            MsgBox("No se puede eliminar este registro")
        End Try
    End Sub

    Private Sub DataGridViewLista_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewLista.CellClick

        Try
            Dim i As Integer
            i = DataGridViewLista.CurrentRow.Index
            TextBoxND.Text = DataGridViewLista.Item(0, i).Value().ToString
            TextBoxTD.Text = DataGridViewLista.Item(1, i).Value().ToString
            TextBoxnombre.Text = DataGridViewLista.Item(2, i).Value().ToString
            TextBoxapellido.Text = DataGridViewLista.Item(3, i).Value().ToString
            TextBoxdireccion.Text = DataGridViewLista.Item(4, i).Value().ToString
            TextBoxtel.Text = DataGridViewLista.Item(5, i).Value().ToString
            TextBoxemail.Text = DataGridViewLista.Item(6, i).Value().ToString
            TextBoxsexo.Text = DataGridViewLista.Item(7, i).Value().ToString
            TextBoxciudad.Text = DataGridViewLista.Item(8, i).Value().ToString
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub RBnombre_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Buttontodos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttontodos.Click

        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            oConnexion.Open()
            ConsultaSql = "SELECT * FROM huespedes ORDER BY Nombre ASC"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewLista.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub TextBoxconsulta_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxconsulta.TextChanged

        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            oConnexion.Open()
            Dim buscar As String
            If IsNumeric(TextBoxconsulta.Text) Then
                buscar = "SELECT * FROM huespedes WHERE Nro_Doc like '%" & TextBoxconsulta.Text & "%'"
            Else
                buscar = "SELECT * FROM huespedes WHERE Nombre like '%" & TextBoxconsulta.Text & "%'"
            End If
            Dim CommandSQL As New MySqlCommand(buscar, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewLista.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As MySqlException
            MsgBox("Error")
        End Try
    End Sub
End Class