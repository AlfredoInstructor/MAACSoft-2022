﻿Imports MySql.Data.MySqlClient
Public Class FormOUT
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConnexion As New MySqlConnection(Cadena)

    Private Sub Buttoncancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Buttontotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttontotal.Click
        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxvalor.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese el valor de la habitacion"
            End If
            If IsNumeric(TextBoxvalor.Text) Then
            Else
                Variable = False
                Mensaje = "porfavor ingrese el valor sin puntos ni comas"
            End If
            If Variable Then
                Dim firstDate, msg As String
                Dim secondDate As Date
                firstDate = TextBoxFentrada.Text
                secondDate = CDate(firstDate)
                msg = "Cantidad de dias a pagar: " & DateDiff(DateInterval.Day, secondDate, Now)
                Dim cantDias As Integer
                cantDias = DateDiff(DateInterval.Day, secondDate, Now)
                Dim precioAPagar As Integer
                precioAPagar = cantDias * CInt(TextBoxvalor.Text)
                TextBoxpagar.Text = precioAPagar.ToString
            Else
                MsgBox(Mensaje)
            End If
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub DataGridViewout_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewout.CellClick
        Try
            Dim i As Integer
            i = DataGridViewout.CurrentRow.Index
            TextBoxid.Text = DataGridViewout.Item(0, i).Value().ToString
            TextBoxND.Text = DataGridViewout.Item(1, i).Value().ToString
            TextBoxNhab.Text = DataGridViewout.Item(2, i).Value().ToString
            TextBoxFentrada.Text = DataGridViewout.Item(3, i).Value().ToString
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Buttonbuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ButtonOUT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonOUT.Click
        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxpagar.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese el total a pagar"
            End If
            If IsNumeric(TextBoxpagar.Text) Then
            Else
                Variable = False
                Mensaje = "porfavor ingrese el valor sin puntos ni comas"
            End If
            Dim updatesql As String = "Update habitaciones Set ocupado = 0  Where Nro_hab =" & TextBoxNhab.Text & ""
            Dim CommandSQL As New MySqlCommand(updatesql, oConnexion)
            Dim oSql As String = "update historial set Fecha_salida ='" & DateTime.Now.ToShortDateString() & "', Total_pagar =" & TextBoxpagar.Text & " where idHISTORIAL =" & TextBoxid.Text & ""
            Dim oCommand As New MySqlCommand(oSql, oConnexion)
            oConnexion.Open()
            oCommand.ExecuteNonQuery()
            CommandSQL.ExecuteNonQuery()
            MsgBox("Check-out completado")
            oConnexion.Close()
            TextBoxid.Text = ""
            TextBoxND.Text = ""
            TextBoxNhab.Text = ""
            TextBoxFentrada.Text = ""
            TextBoxvalor.Text = ""
            TextBoxpagar.Text = ""
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxid.TextChanged

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub TextBoxpagar_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxpagar.TextChanged

    End Sub

    Private Sub TextBoxbuscar_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxbuscar.TextChanged
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            oConnexion.Open()
            Dim ConsultaSql As String = "SELECT * FROM historial WHERE  Nro_Doc like '%" & TextBoxbuscar.Text & "%' And Fecha_salida Is Null;"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewout.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub
End Class