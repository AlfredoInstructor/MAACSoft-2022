﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormNacionalidades
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridViewBusquedadoc = New System.Windows.Forms.DataGridView()
        Me.ButtonCANCELAR = New System.Windows.Forms.Button()
        Me.TextBoxPaís = New System.Windows.Forms.TextBox()
        Me.TextBoxTD = New System.Windows.Forms.TextBox()
        Me.GBalta = New System.Windows.Forms.GroupBox()
        Me.Buttonguardar = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Buttonlista = New System.Windows.Forms.Button()
        CType(Me.DataGridViewBusquedadoc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GBalta.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridViewBusquedadoc
        '
        Me.DataGridViewBusquedadoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewBusquedadoc.Location = New System.Drawing.Point(12, 12)
        Me.DataGridViewBusquedadoc.Name = "DataGridViewBusquedadoc"
        Me.DataGridViewBusquedadoc.Size = New System.Drawing.Size(330, 150)
        Me.DataGridViewBusquedadoc.TabIndex = 0
        '
        'ButtonCANCELAR
        '
        Me.ButtonCANCELAR.Location = New System.Drawing.Point(266, 317)
        Me.ButtonCANCELAR.Name = "ButtonCANCELAR"
        Me.ButtonCANCELAR.Size = New System.Drawing.Size(76, 23)
        Me.ButtonCANCELAR.TabIndex = 4
        Me.ButtonCANCELAR.Text = "SALIR"
        Me.ButtonCANCELAR.UseVisualStyleBackColor = True
        '
        'TextBoxPaís
        '
        Me.TextBoxPaís.Location = New System.Drawing.Point(67, 62)
        Me.TextBoxPaís.Name = "TextBoxPaís"
        Me.TextBoxPaís.Size = New System.Drawing.Size(150, 20)
        Me.TextBoxPaís.TabIndex = 6
        '
        'TextBoxTD
        '
        Me.TextBoxTD.Location = New System.Drawing.Point(67, 33)
        Me.TextBoxTD.Name = "TextBoxTD"
        Me.TextBoxTD.Size = New System.Drawing.Size(150, 20)
        Me.TextBoxTD.TabIndex = 7
        '
        'GBalta
        '
        Me.GBalta.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.GBalta.Controls.Add(Me.Buttonguardar)
        Me.GBalta.Controls.Add(Me.Label2)
        Me.GBalta.Controls.Add(Me.Label1)
        Me.GBalta.Controls.Add(Me.TextBoxTD)
        Me.GBalta.Controls.Add(Me.TextBoxPaís)
        Me.GBalta.Location = New System.Drawing.Point(13, 211)
        Me.GBalta.Name = "GBalta"
        Me.GBalta.Size = New System.Drawing.Size(329, 100)
        Me.GBalta.TabIndex = 8
        Me.GBalta.TabStop = False
        Me.GBalta.Text = "Nuevo Documento:"
        '
        'Buttonguardar
        '
        Me.Buttonguardar.Location = New System.Drawing.Point(253, 64)
        Me.Buttonguardar.Name = "Buttonguardar"
        Me.Buttonguardar.Size = New System.Drawing.Size(76, 23)
        Me.Buttonguardar.TabIndex = 9
        Me.Buttonguardar.Text = "GUARDAR"
        Me.Buttonguardar.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "País:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Tipo Doc:"
        '
        'Buttonlista
        '
        Me.Buttonlista.Location = New System.Drawing.Point(263, 168)
        Me.Buttonlista.Name = "Buttonlista"
        Me.Buttonlista.Size = New System.Drawing.Size(79, 23)
        Me.Buttonlista.TabIndex = 2
        Me.Buttonlista.Text = "LISTAR"
        Me.Buttonlista.UseVisualStyleBackColor = True
        '
        'FormNacionalidades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(357, 347)
        Me.Controls.Add(Me.GBalta)
        Me.Controls.Add(Me.ButtonCANCELAR)
        Me.Controls.Add(Me.Buttonlista)
        Me.Controls.Add(Me.DataGridViewBusquedadoc)
        Me.Name = "FormNacionalidades"
        Me.Text = "DOCUMENTOS"
        CType(Me.DataGridViewBusquedadoc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GBalta.ResumeLayout(False)
        Me.GBalta.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridViewBusquedadoc As System.Windows.Forms.DataGridView
    Friend WithEvents ButtonCANCELAR As System.Windows.Forms.Button
    Friend WithEvents TextBoxPaís As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxTD As System.Windows.Forms.TextBox
    Friend WithEvents GBalta As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Buttonguardar As System.Windows.Forms.Button
    Friend WithEvents Buttonlista As System.Windows.Forms.Button
End Class
