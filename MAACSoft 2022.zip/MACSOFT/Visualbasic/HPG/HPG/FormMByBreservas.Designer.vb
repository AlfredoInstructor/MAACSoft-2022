﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMByBreservas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMByBreservas))
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TextBoxbusqueda = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ButtonBuscar = New System.Windows.Forms.Button()
        Me.Buttoneliminar = New System.Windows.Forms.Button()
        Me.Buttoncerrar = New System.Windows.Forms.Button()
        Me.Buttonmodificar = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBoxND = New System.Windows.Forms.TextBox()
        Me.TextBoxNrohab = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxcambiar = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBoxidreservas = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridViewreservas = New System.Windows.Forms.DataGridView()
        Me.ButtonTR = New System.Windows.Forms.Button()
        Me.Buttontodas = New System.Windows.Forms.Button()
        Me.DateTimePickerreserva = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridViewreservas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Silver
        Me.GroupBox3.Controls.Add(Me.TextBoxbusqueda)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(244, 48)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Buscar:"
        '
        'TextBoxbusqueda
        '
        Me.TextBoxbusqueda.Location = New System.Drawing.Point(97, 16)
        Me.TextBoxbusqueda.Name = "TextBoxbusqueda"
        Me.TextBoxbusqueda.Size = New System.Drawing.Size(132, 20)
        Me.TextBoxbusqueda.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Nro Documento:"
        '
        'ButtonBuscar
        '
        Me.ButtonBuscar.BackColor = System.Drawing.Color.Gainsboro
        Me.ButtonBuscar.Location = New System.Drawing.Point(262, 12)
        Me.ButtonBuscar.Name = "ButtonBuscar"
        Me.ButtonBuscar.Size = New System.Drawing.Size(122, 27)
        Me.ButtonBuscar.TabIndex = 11
        Me.ButtonBuscar.Text = "BUSCAR"
        Me.ButtonBuscar.UseVisualStyleBackColor = False
        '
        'Buttoneliminar
        '
        Me.Buttoneliminar.BackColor = System.Drawing.Color.Gainsboro
        Me.Buttoneliminar.Location = New System.Drawing.Point(306, 302)
        Me.Buttoneliminar.Name = "Buttoneliminar"
        Me.Buttoneliminar.Size = New System.Drawing.Size(78, 45)
        Me.Buttoneliminar.TabIndex = 13
        Me.Buttoneliminar.Text = "ELIMINAR"
        Me.Buttoneliminar.UseVisualStyleBackColor = False
        '
        'Buttoncerrar
        '
        Me.Buttoncerrar.BackColor = System.Drawing.Color.Gainsboro
        Me.Buttoncerrar.Location = New System.Drawing.Point(306, 350)
        Me.Buttoncerrar.Name = "Buttoncerrar"
        Me.Buttoncerrar.Size = New System.Drawing.Size(78, 45)
        Me.Buttoncerrar.TabIndex = 14
        Me.Buttoncerrar.Text = "CERRAR"
        Me.Buttoncerrar.UseVisualStyleBackColor = False
        '
        'Buttonmodificar
        '
        Me.Buttonmodificar.BackColor = System.Drawing.Color.Gainsboro
        Me.Buttonmodificar.Location = New System.Drawing.Point(306, 254)
        Me.Buttonmodificar.Name = "Buttonmodificar"
        Me.Buttonmodificar.Size = New System.Drawing.Size(78, 45)
        Me.Buttonmodificar.TabIndex = 15
        Me.Buttonmodificar.Text = "MODIFICAR"
        Me.Buttonmodificar.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Gainsboro
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Segoe MDL2 Assets", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(9, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 17)
        Me.Label5.TabIndex = 43
        Me.Label5.Text = "Nº Documento:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Gainsboro
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Segoe MDL2 Assets", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 98)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 17)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Nº Habitacion:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Gainsboro
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Segoe MDL2 Assets", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 133)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 17)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Fecha Entrada:"
        '
        'TextBoxND
        '
        Me.TextBoxND.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBoxND.Location = New System.Drawing.Point(123, 61)
        Me.TextBoxND.Name = "TextBoxND"
        Me.TextBoxND.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxND.TabIndex = 47
        '
        'TextBoxNrohab
        '
        Me.TextBoxNrohab.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBoxNrohab.Location = New System.Drawing.Point(108, 98)
        Me.TextBoxNrohab.Name = "TextBoxNrohab"
        Me.TextBoxNrohab.Size = New System.Drawing.Size(50, 20)
        Me.TextBoxNrohab.TabIndex = 48
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.GroupBox1.Controls.Add(Me.DateTimePickerreserva)
        Me.GroupBox1.Controls.Add(Me.TextBoxcambiar)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.TextBoxidreservas)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TextBoxNrohab)
        Me.GroupBox1.Controls.Add(Me.TextBoxND)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 218)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(296, 179)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Reserva:"
        '
        'TextBoxcambiar
        '
        Me.TextBoxcambiar.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBoxcambiar.Location = New System.Drawing.Point(238, 98)
        Me.TextBoxcambiar.Name = "TextBoxcambiar"
        Me.TextBoxcambiar.Size = New System.Drawing.Size(50, 20)
        Me.TextBoxcambiar.TabIndex = 54
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Gainsboro
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Segoe MDL2 Assets", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(159, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 17)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "Cambiar a :"
        '
        'TextBoxidreservas
        '
        Me.TextBoxidreservas.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBoxidreservas.Location = New System.Drawing.Point(122, 24)
        Me.TextBoxidreservas.Name = "TextBoxidreservas"
        Me.TextBoxidreservas.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxidreservas.TabIndex = 52
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Gainsboro
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("Segoe MDL2 Assets", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 17)
        Me.Label6.TabIndex = 51
        Me.Label6.Text = "ID Reserva:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Silver
        Me.GroupBox2.Controls.Add(Me.DataGridViewreservas)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 78)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(368, 134)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Lista:"
        '
        'DataGridViewreservas
        '
        Me.DataGridViewreservas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewreservas.Location = New System.Drawing.Point(9, 20)
        Me.DataGridViewreservas.Name = "DataGridViewreservas"
        Me.DataGridViewreservas.Size = New System.Drawing.Size(353, 108)
        Me.DataGridViewreservas.TabIndex = 0
        '
        'ButtonTR
        '
        Me.ButtonTR.BackColor = System.Drawing.Color.Gainsboro
        Me.ButtonTR.Location = New System.Drawing.Point(306, 212)
        Me.ButtonTR.Name = "ButtonTR"
        Me.ButtonTR.Size = New System.Drawing.Size(78, 42)
        Me.ButtonTR.TabIndex = 16
        Me.ButtonTR.Text = "TOTAL RESERVAS"
        Me.ButtonTR.UseVisualStyleBackColor = False
        '
        'Buttontodas
        '
        Me.Buttontodas.BackColor = System.Drawing.Color.Gainsboro
        Me.Buttontodas.Location = New System.Drawing.Point(262, 45)
        Me.Buttontodas.Name = "Buttontodas"
        Me.Buttontodas.Size = New System.Drawing.Size(122, 27)
        Me.Buttontodas.TabIndex = 17
        Me.Buttontodas.Text = "MOSTRAR TODO"
        Me.Buttontodas.UseVisualStyleBackColor = False
        '
        'DateTimePickerreserva
        '
        Me.DateTimePickerreserva.Location = New System.Drawing.Point(113, 133)
        Me.DateTimePickerreserva.Name = "DateTimePickerreserva"
        Me.DateTimePickerreserva.Size = New System.Drawing.Size(175, 20)
        Me.DateTimePickerreserva.TabIndex = 55
        '
        'FormMByBreservas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(392, 412)
        Me.Controls.Add(Me.Buttontodas)
        Me.Controls.Add(Me.ButtonTR)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Buttonmodificar)
        Me.Controls.Add(Me.Buttoncerrar)
        Me.Controls.Add(Me.Buttoneliminar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.ButtonBuscar)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormMByBreservas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Búsqueda de Reservas:"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridViewreservas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ButtonBuscar As System.Windows.Forms.Button
    Friend WithEvents TextBoxbusqueda As System.Windows.Forms.TextBox
    Friend WithEvents Buttoneliminar As System.Windows.Forms.Button
    Friend WithEvents Buttoncerrar As System.Windows.Forms.Button
    Friend WithEvents Buttonmodificar As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBoxND As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxNrohab As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxidreservas As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridViewreservas As System.Windows.Forms.DataGridView
    Friend WithEvents ButtonTR As System.Windows.Forms.Button
    Friend WithEvents Buttontodas As System.Windows.Forms.Button
    Friend WithEvents TextBoxcambiar As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerreserva As System.Windows.Forms.DateTimePicker
End Class
