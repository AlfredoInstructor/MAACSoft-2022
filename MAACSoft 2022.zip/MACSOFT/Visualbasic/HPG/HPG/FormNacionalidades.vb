﻿Imports MySql.Data.MySqlClient
Public Class FormNacionalidades
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConnexion As New MySqlConnection(Cadena)

    Private Sub ButtonCANCELAR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCANCELAR.Click
        Me.Close()

    End Sub

    Private Sub DataGridViewBusquedadoc_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridViewBusquedadoc.CellContentClick

    End Sub

    Private Sub GBalta_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GBalta.Enter

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxPaís.TextChanged

    End Sub

    Private Sub Buttonlista_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonlista.Click, Buttonlista.Click
        Try
            Dim oConnexion As New MySqlConnection(Cadena)
            Dim ConsultaSql As String
            oConnexion.Open()
            ConsultaSql = "SELECT * FROM nacionalidades"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Adapterhpg.SelectCommand = CommandSQL
            Dim dbdataset As New DataTable
            Adapterhpg.Fill(dbdataset)
            DataGridViewBusquedadoc.DataSource = dbdataset
            oConnexion.Close()
        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub

    Private Sub Buttonguardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonguardar.Click
        Try
            Dim Variable As Boolean = True
            Dim Mensaje As String = ""
            If TextBoxPaís.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese el Pais"
            End If
            If TextBoxTD.Text = String.Empty Then
                Variable = False
                Mensaje = "ingrese el tipo de documento"
            End If
            If Variable Then
                oConnexion.Open()
                Dim oSql As String = "insert into nacionalidades(Tipo_Doc, País) values('" & TextBoxTD.Text & "', '" & TextBoxPaís.Text & "')"
                Dim oCommand As New MySqlCommand(oSql, oConnexion)
                oCommand.ExecuteNonQuery()
                MsgBox("se guardado el registro")
                TextBoxPaís.Text = ""
                TextBoxTD.Text = ""
                Dim ConsultaSql As String = "SELECT * FROM nacionalidades"
                Dim CommandSQL As New MySqlCommand(ConsultaSql, oConnexion)
                Dim Adapterhpg As New MySqlDataAdapter
                Adapterhpg.SelectCommand = CommandSQL
                Dim dbdataset As New DataTable
                Adapterhpg.Fill(dbdataset)
                DataGridViewBusquedadoc.DataSource = dbdataset
                oConnexion.Close()
            Else
                MsgBox(Mensaje)
                oConnexion.Close()
            End If

        Catch ex As Exception
            MsgBox("Error, ingrese los datos correctamente")
            oConnexion.Close()
        End Try

    End Sub
End Class