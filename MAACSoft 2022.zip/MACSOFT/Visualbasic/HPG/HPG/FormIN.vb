﻿Imports MySql.Data.MySqlClient
Public Class FormIN
    Public Cadena As String = "server=localhost;port=3306;user id=root;password=admin;database=hpg"
    Dim oConexion As New MySqlConnection(Cadena)

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()

    End Sub

    Private Sub Buttonaceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonaceptar.Click
        Try
            Dim rsexiste As MySqlDataReader
            Dim consultaex As String = " select count(*) from huespedes where Nro_Doc =" & TextBoxNrodocresp.Text
            oConexion.Open()
            Dim Commandconsult As New MySqlCommand(consultaex, oConexion)
            Dim siExiste As Integer
            rsexiste = Commandconsult.ExecuteReader()
            rsexiste.Read()
            siExiste = rsexiste(0)
            oConexion.Close()

            Dim rsexiste1 As MySqlDataReader
            Dim consultaex1 As String = " select count(*) from habitaciones where Nro_hab =" & TextBoxNrohab.Text
            oConexion.Open()
            Dim Commandconsult1 As New MySqlCommand(consultaex1, oConexion)
            Dim siExiste1 As Integer
            rsexiste1 = Commandconsult1.ExecuteReader()
            rsexiste1.Read()
            siExiste1 = rsexiste1(0)
            oConexion.Close()

            Dim rsOcupa As MySqlDataReader
            Dim ocupado As String = " select ocupado from habitaciones where Nro_Hab =" & TextBoxNrohab.Text
            oConexion.Open()
            Dim CommandSQL1 As New MySqlCommand(ocupado, oConexion)
            Dim ocupado1 As Integer
            rsOcupa = CommandSQL1.ExecuteReader()
            rsOcupa.Read()
            ocupado1 = rsOcupa(0)
            oConexion.Close()

            oConexion.Open()
            Dim rsReserva As MySqlDataReader
            Dim reservado As String = " select reservado from habitaciones where Nro_Hab =" & TextBoxNrohab.Text & ""
            Dim CommandSQL2 As New MySqlCommand(reservado, oConexion)
            Dim reservado1 As Integer
            rsReserva = CommandSQL2.ExecuteReader()
            rsReserva.Read()
            reservado1 = rsReserva(0)
            oConexion.Close()

            Dim Variable As Boolean = True
            Dim Mensaje As String = ""

            If siExiste1 = 1 Then
            Else
                Variable = False
                Mensaje = "numero de habitacion no existe, porfavor ingrese otra"
            End If
            If siExiste = 1 Then
            Else
                Variable = False
                Mensaje = "numero de documento no existe, ingrese otro o de alta de huesped"
            End If

            If Variable Then
                If ocupado1 = 1 Then
                    MsgBox("habitacion ocupada porfavor ingrese otra")
                ElseIf reservado1 = 1 Then
                    MsgBox("habitacion reservada porfavor ingrese otra")
                Else
                    oConexion.Open()
                    Dim updatesql As String = "Update habitaciones Set ocupado = 1  Where Nro_hab =" & TextBoxNrohab.Text & ""
                    Dim CommandSQL As New MySqlCommand(updatesql, oConexion)

                    Dim oSql As String = "insert into historial(Nro_Doc, Nro_hab, fecha_entrada) values(" & TextBoxNrodocresp.Text & "," & TextBoxNrohab.Text & ",'" & DateTime.Now.ToShortDateString() & "')"
                    Dim oCommand As New MySqlCommand(oSql, oConexion)

                    oCommand.ExecuteNonQuery()

                    CommandSQL.ExecuteNonQuery()
                    oConexion.Close()
                    MsgBox("Registro completado")
                End If
            Else
                MsgBox(Mensaje)
            End If

        Catch ex As Exception
            MsgBox("ERROR, intentelo de nuevo")

        End Try
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGVRESP.CellContentClick

    End Sub

    Private Sub BUSCAR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BUSCAR.Click
        Try
            oConexion.Open()
            Dim ConsultaSql As String = "SELECT * FROM historial WHERE Nro_Doc ='" & TextBoxResp.Text & "' And Fecha_salida Is Null;"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Dim dbdataset As New DataTable
            Adapterhpg.SelectCommand = CommandSQL
            Adapterhpg.Fill(dbdataset)
            DGVRESP.DataSource = dbdataset
            oConexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
        
    End Sub

    Private Sub DGVRESP_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGVRESP.CellClick
        Dim i As Integer
        i = DGVRESP.CurrentRow.Index
        TextBoxID.Text = DGVRESP.Item(0, i).Value().ToString
    End Sub

    Private Sub TextBoxResp_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxResp.TextChanged

    End Sub

    Private Sub ButtonTODOS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonTODOS.Click
        Try
            oConexion.Open()
            Dim ConsultaSql As String = "SELECT * FROM historial WHERE Fecha_salida Is Null;"
            Dim CommandSQL As New MySqlCommand(ConsultaSql, oConexion)
            Dim Adapterhpg As New MySqlDataAdapter
            Dim dbdataset As New DataTable
            Adapterhpg.SelectCommand = CommandSQL
            Adapterhpg.Fill(dbdataset)
            DGVRESP.DataSource = dbdataset
            oConexion.Close()
        Catch ex As Exception
            MsgBox("Error")
        End Try
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            oConexion.Open()
            Dim oSql As String = "insert into Ocupan (Nro_Doc, idHISTORIAL) values(" & TextBoxdoc.Text & "," & TextBoxID.Text & ")"
            Dim oCommand As New MySqlCommand(oSql, oConexion)
            oCommand.ExecuteNonQuery()
            oConexion.Close()
            MsgBox("acompañante ingresado")
        Catch ex As Exception
            MsgBox("complete los campos correctamente")
        End Try
    End Sub

    Private Sub Buttonnuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonnuevo.Click
        FormAltahuesped.Show()
    End Sub

    Private Sub ButtonHab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonHab.Click
        Formbusquedahab.Show()
    End Sub
End Class