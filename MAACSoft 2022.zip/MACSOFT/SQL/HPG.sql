-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: localhost    Database: hpg
-- ------------------------------------------------------
-- Server version	5.5.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `hpg`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `hpg` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `hpg`;

--
-- Table structure for table `habitaciones`
--

DROP TABLE IF EXISTS `habitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `habitaciones` (
  `Nro_Hab` int(11) NOT NULL,
  `Nro_cama` int(11) NOT NULL,
  `tipo_de_cama` varchar(45) NOT NULL,
  `V_al_Frente` int(11) NOT NULL,
  `AC` int(11) NOT NULL,
  `Frigobar` int(11) NOT NULL,
  `TVcolor` int(11) NOT NULL,
  `Ocupado` int(11) NOT NULL,
  `Reservado` int(11) DEFAULT NULL,
  PRIMARY KEY (`Nro_Hab`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitaciones`
--

LOCK TABLES `habitaciones` WRITE;
/*!40000 ALTER TABLE `habitaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `habitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial`
--

DROP TABLE IF EXISTS `historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historial` (
  `idHISTORIAL` int(11) NOT NULL,
  `Nro_Doc` int(11) NOT NULL,
  `Nro_hab` int(11) NOT NULL,
  `Fecha_entrada` date NOT NULL,
  `Fecha_salida` date DEFAULT NULL,
  `Total_pagar` int(20) DEFAULT NULL,
  PRIMARY KEY (`idHISTORIAL`),
  KEY `FK_4` (`Nro_Doc`),
  KEY `FK_5` (`Nro_hab`),
  CONSTRAINT `FK_4` FOREIGN KEY (`Nro_Doc`) REFERENCES `huespedes` (`Nro_Doc`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_5` FOREIGN KEY (`Nro_hab`) REFERENCES `habitaciones` (`Nro_Hab`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial`
--

LOCK TABLES `historial` WRITE;
/*!40000 ALTER TABLE `historial` DISABLE KEYS */;
/*!40000 ALTER TABLE `historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `huespedes`
--

DROP TABLE IF EXISTS `huespedes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huespedes` (
  `Nro_Doc` int(11) NOT NULL,
  `Tipo_Doc` varchar(45) DEFAULT NULL,
  `Nombre` varchar(45) DEFAULT NULL,
  `Apellido` varchar(45) DEFAULT NULL,
  `Dirección` varchar(45) DEFAULT NULL,
  `Telefono` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `sexo` varchar(45) DEFAULT NULL,
  `Ciudad_origen` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Nro_Doc`),
  KEY `FK_1` (`Tipo_Doc`),
  CONSTRAINT `FK_1` FOREIGN KEY (`Tipo_Doc`) REFERENCES `nacionalidades` (`Tipo_Doc`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `huespedes`
--

LOCK TABLES `huespedes` WRITE;
/*!40000 ALTER TABLE `huespedes` DISABLE KEYS */;
/*!40000 ALTER TABLE `huespedes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nacionalidades`
--

DROP TABLE IF EXISTS `nacionalidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nacionalidades` (
  `Tipo_Doc` varchar(45) NOT NULL,
  `País` varchar(45) NOT NULL,
  PRIMARY KEY (`Tipo_Doc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nacionalidades`
--

LOCK TABLES `nacionalidades` WRITE;
/*!40000 ALTER TABLE `nacionalidades` DISABLE KEYS */;
/*!40000 ALTER TABLE `nacionalidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ocupan`
--

DROP TABLE IF EXISTS `ocupan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ocupan` (
  `idacompañantes` int(11) NOT NULL,
  `idHISTORIAL` int(11) NOT NULL,
  `Nro_Doc` int(11) NOT NULL,
  PRIMARY KEY (`idacompañantes`),
  KEY `FK_6` (`idHISTORIAL`),
  KEY `FK_7` (`idHISTORIAL`),
  CONSTRAINT `FK_6` FOREIGN KEY (`idHISTORIAL`) REFERENCES `huespedes` (`Nro_Doc`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_7` FOREIGN KEY (`idHISTORIAL`) REFERENCES `historial` (`idHISTORIAL`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ocupan`
--

LOCK TABLES `ocupan` WRITE;
/*!40000 ALTER TABLE `ocupan` DISABLE KEYS */;
/*!40000 ALTER TABLE `ocupan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resevas`
--

DROP TABLE IF EXISTS `resevas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resevas` (
  `idRESERVAS` int(11) NOT NULL,
  `Nro_Doc` int(11) NOT NULL,
  `Nro_hab` int(11) NOT NULL,
  `fecha_entrada` date NOT NULL,
  PRIMARY KEY (`idRESERVAS`),
  KEY `FK_2` (`Nro_hab`),
  KEY `FK_3` (`Nro_Doc`),
  CONSTRAINT `FK_2` FOREIGN KEY (`Nro_hab`) REFERENCES `habitaciones` (`Nro_Hab`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_3` FOREIGN KEY (`Nro_Doc`) REFERENCES `huespedes` (`Nro_Doc`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resevas`
--

LOCK TABLES `resevas` WRITE;
/*!40000 ALTER TABLE `resevas` DISABLE KEYS */;
/*!40000 ALTER TABLE `resevas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-14  1:41:58
